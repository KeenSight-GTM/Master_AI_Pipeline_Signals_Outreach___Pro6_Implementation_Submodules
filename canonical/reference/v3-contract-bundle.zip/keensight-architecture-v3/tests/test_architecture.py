from __future__ import annotations
import copy,json,shutil,subprocess,sys
from pathlib import Path
import pytest
from jsonschema import Draft7Validator,FormatChecker
from catalog import ROOT,read_json,load_authored
from contract_schema import SCHEMAS
from validate import Bundle,Invalid,validate_bundle
from contract_tools.rules import evaluate,wilson
from contract_tools.graphs import build_graph,dirty_closure,topological_order
from contract_tools.identity import claim_key,observation_key,current_per_source,slot_for
from contract_tools.fingerprints import match

REG=load_authored(); FLOWS=REG['derivations']

def flow(a): return copy.deepcopy(next(x for x in FLOWS if x['algorithm']==a))
def features(a): return copy.deepcopy(flow(a)['fixtures'][0]['features'])
def edit(root,kind,identifier,changes):
    paths=list((root/'registry').glob(f'{kind}.json')) if kind in REG else list((root/'instances'/kind).glob('*.json'))
    for path in paths:
        data=read_json(path);rows=data if isinstance(data,list) else [data]
        for row in rows:
            if identifier in row.values():
                changes(row);path.write_text(json.dumps(data,indent=2)+'\n');return
    raise AssertionError((kind,identifier))

@pytest.fixture
def bundle(tmp_path):
    p=tmp_path/'bundle';shutil.copytree(ROOT,p,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','reports'));return p

def test_full_design_release_passes():
    r=validate_bundle();assert r['predicates']==87 and r['derivations']==23 and r['signal_types']==18

def test_generated_files_exact():
    subprocess.run([sys.executable,'generate_structures.py','--check'],cwd=ROOT,check=True,capture_output=True)

@pytest.mark.parametrize('algorithm,fixture',[(f['algorithm'],x['label']) for f in FLOWS for x in f['fixtures']])
def test_all_frozen_kernel_fixtures(algorithm,fixture):
    f=flow(algorithm);fx=next(x for x in f['fixtures'] if x['label']==fixture)
    assert evaluate(f,fx['features'])==fx['expect']

CASES=[
('unsupported_copy','packages','package.fixture',lambda r:r.update(rendered_text="Your booking and CRM still don't talk."),'UNGROUNDED'),
('unknown_hook','facts','fact.calendly',lambda r:r.update(state='UNKNOWN',object=None),'UNKNOWN_OR_ABSENCE'),
('absent_hook','facts','fact.calendly',lambda r:r.update(state='NOT_FOUND',object=None),'ABSENCE_WITHOUT'),
('cross_account_hook','packages','package.fixture',lambda r:r['claims'][0].update(fact_id='fact.no-booking'),'CROSS_SUBJECT'),
('cross_account_signal','signals','signal.lowcode',lambda r:r['input_fact_ids'].append('fact.no-booking'),'CROSS_SUBJECT'),
('candidate_hook_source','sources','source.vendor.present@3.0.0',lambda r:r.update(authority='candidate'),'INACTIVE_SOURCE'),
('candidate_ancestor','sources','source.ops.automation.verified@3.0.0',lambda r:r.update(authority='candidate'),'INACTIVE_SOURCE'),
('candidate_derivation','derivations','deriv.automation-maturity@2.0.0',lambda r:r.update(authority='candidate'),'INACTIVE_DERIVATION'),
('stale_hook','facts','fact.calendly',lambda r:r.update(observed_at='2020-01-01T00:00:00Z'),'STALE'),
('future_hook','facts','fact.calendly',lambda r:r.update(observed_at='2099-01-01T00:00:00Z'),'FUTURE'),
('unbound_hook','scopes','scope.acme',lambda r:r.update(binding='UNBOUND'),'UNBOUND'),
('wrong_pack','signals','signal.lowcode',lambda r:r.update(source_pack='pack.ai-seo@3.0.0'),'WRONG_PACK'),
('duplicate_pack','signal-packs','pack.ai-seo@3.0.0',lambda r:r['signal_types'].append('LOWCODE_ACTIVE'),'DUPLICATE_PACK'),
('empty_resolved','signals','signal.lowcode',lambda r:r.update(input_fact_ids=[]),'EMPTY_RESOLVED'),
('resolved_suppression','signals','signal.lowcode',lambda r:r.update(reason='DNC'),'SCHEMA'),
('unknown_status','signals','signal.lowcode',lambda r:r.update(status='WINNER'),'SCHEMA'),
('bad_date','facts','fact.calendly',lambda r:r.update(observed_at='not-a-date'),'SCHEMA'),
('bad_ttl','sources','source.vendor.present@3.0.0',lambda r:r.update(ttl_seconds='Potato'),'SCHEMA'),
('zero_ttl','sources','source.vendor.present@3.0.0',lambda r:r.update(ttl_seconds=0),'SCHEMA'),
('bad_enum','facts','fact.maturity',lambda r:r.update(object='L99'),'predicate-value'),
('wrong_value_type','facts','fact.calendly',lambda r:r.update(object=123),'predicate-value'),
('extra_value_field','facts','fact.calendly',lambda r:r['object'].update(invented=True),'predicate-value'),
('unknown_operator','fingerprints','fp.calendly-asset@3.0.0',lambda r:r['operators'][0].update(op='raw_regex'),'SCHEMA'),
('empty_tests','fingerprints','fp.calendly-asset@3.0.0',lambda r:r['tests'].update(must_not_fire=[]),'SCHEMA'),
('missing_coverage','evidence','evidence.fact.no-booking',lambda r:r.update(coverage_id=None),'ABSENCE_WITHOUT'),
('incomplete_coverage','coverage','coverage.northside',lambda r:r.update(status='INCOMPLETE'),'ABSENCE_INCOMPLETE'),
('truncated_negative','snapshots','snap.northside',lambda r:r.update(truncated=True),'INCOMPLETE_COVERAGE'),
('wrong_coverage_scope','coverage','coverage.northside',lambda r:r.update(scope_id='scope.acme'),'COVERAGE_SCOPE'),
('coverage_flag','signal-types','SEO_SCHEMA_ABSENT',lambda r:r.update(requires_coverage=False),'MISSING_DECLARED_COVERAGE'),
('dangling_input','signals','signal.lowcode',lambda r:r['input_fact_ids'].append('fact.nonexistent'),'UNRESOLVED_REFERENCE'),
('bad_angle_ref','packages','package.fixture',lambda r:r.update(angle_pack='angle.nonexistent'),'UNRESOLVED_REFERENCE'),
('bad_adj_ref','packages','package.fixture',lambda r:r.update(adjudication_id='adj.nonexistent'),'UNRESOLVED_REFERENCE'),
('bad_package_status','packages','package.fixture',lambda r:r.update(status='SEND_NOW'),'SCHEMA'),
('same_rung','packages','package.fixture',lambda r:r.update(offered_rung='L1'),'NOT_ONE_RUNG_UP'),
('missing_slot','angle-packs','angle.booking-assessment@3.0.0',lambda r:r['required_slots'].append('location.primary'),'MISSING_REQUIRED_SLOT'),
('suppressed_requirement','signals','signal.lowcode',lambda r:r.update(status='SUPPRESSED',reason='DNC'),'ADJUDICATION_STATUS'),
('dangling_output','derivations','deriv.business-type@2.0.0',lambda r:r['outputs'].append('unregistered.output'),'DERIVED_BY_BACKLINK|DERIVATION_SOURCE_OUTPUTS'),
('missing_raw_capture','evidence','evidence.fact.calendly',lambda r:r.update(snapshot_ids=[]),'EMPTY_PROVENANCE'),
('missing_execution','evidence','evidence.fact.maturity',lambda r:r.update(execution_id=None),'MISSING_DERIVATION_EXECUTION'),
('false_derived_value','facts','fact.maturity',lambda r:r.update(object='L3'),'EXECUTED_DERIVATION_MISMATCH'),
('bad_claim_slot','facts','fact.calendly',lambda r:r.update(claim_slot='["hubspot"]'),'CLAIM_SLOT_MISMATCH'),
('wrong_source_emission','facts','fact.calendly',lambda r:r.update(source='source.crm.present@3.0.0'),'SOURCE_CANNOT_EMIT'),
('source_prior_out_of_range','sources','source.vendor.present@3.0.0',lambda r:r.update(confidence_prior=1.1),'SCHEMA'),
('unsafe_tie_policy','adjudication-packs','adj.core@3.0.0',lambda r:r.update(tie='FIRST_DECLARED'),'SCHEMA'),
('copy_question_premise','questions','booking_crm_handoff',lambda r:r.update(text='Why is your CRM disconnected?'),'UNAPPROVED_QUESTION'),
('production_fixture','runs','run.fixture',lambda r:r.update(mode='PRODUCTION'),'PRODUCTION_DISABLED'),
]

@pytest.mark.parametrize('name,kind,identifier,change,error',CASES,ids=[x[0] for x in CASES])
def test_semantic_mutations_rejected_without_checksum_shortcut(bundle,name,kind,identifier,change,error):
    edit(bundle,kind,identifier,change)
    with pytest.raises((Invalid,ValueError),match=error): validate_bundle(bundle,verify_release=False)

def test_valid_derived_fact_reference_is_indexed(bundle):
    edit(bundle,'signals','signal.lowcode',lambda r:r['input_fact_ids'].append('fact.maturity'))
    validate_bundle(bundle,verify_release=False)

def test_additional_malformed_disk_instance_is_not_ignored(bundle):
    (bundle/'instances/facts/extra.json').write_text('{"fact_id":"unvalidated"}')
    with pytest.raises(Invalid,match='SCHEMA'): validate_bundle(bundle,verify_release=False)

def test_unknown_instance_directory_rejected(bundle):
    p=bundle/'instances/unregistered';p.mkdir();(p/'extra.json').write_text('{}')
    with pytest.raises(Invalid,match='UNDECLARED_INSTANCE_PATH'): validate_bundle(bundle,verify_release=False)

def test_duplicate_id_rejected(bundle):
    shutil.copyfile(bundle/'instances/facts/001.json',bundle/'instances/facts/duplicate.json')
    with pytest.raises(Invalid,match='DUPLICATE_ID'): validate_bundle(bundle,verify_release=False)

def test_duplicate_json_key_rejected(bundle):
    p=bundle/'instances/facts/extra.json';p.write_text('{"fact_id":"a","fact_id":"b"}')
    with pytest.raises(ValueError,match='DUPLICATE_JSON_KEY'):validate_bundle(bundle,verify_release=False)

def test_content_tampering_rejected_even_without_release_check(bundle):
    (bundle/'fixtures/no-booking.html').write_text('tampered')
    with pytest.raises(Invalid,match='CONTENT_INTEGRITY'):validate_bundle(bundle,verify_release=False)

def test_provenance_self_cycle(bundle):
    edit(bundle,'evidence','evidence.fact.calendly',lambda r:r['input_fact_ids'].append('fact.calendly'))
    with pytest.raises(ValueError,match='SELF_CYCLE'):validate_bundle(bundle,verify_release=False)

@pytest.mark.parametrize('edges',[
 [{'from':'a','to':'a','kind':'data','epoch_lag':0}],
 [{'from':'a','to':'b','kind':'data','epoch_lag':0},{'from':'b','to':'a','kind':'data','epoch_lag':0}],
 [{'from':'a','to':'b','kind':'control','epoch_lag':0},{'from':'b','to':'a','kind':'data','epoch_lag':0}],
])
def test_dependency_cycles_fail(edges):
    with pytest.raises(ValueError,match='CYCLE'):topological_order([{'node_id':'a'},{'node_id':'b'}],edges)

def test_prior_epoch_feedback_does_not_create_same_epoch_cycle():
    edges=[{'from':'a','to':'b','kind':'data','epoch_lag':0},{'from':'b','to':'a','kind':'feedback','epoch_lag':1}]
    assert topological_order([{'node_id':'a'},{'node_id':'b'}],edges)==['a','b']

def test_non_feedback_lag_rejected():
    with pytest.raises(ValueError,match='ONLY_FEEDBACK'):topological_order([{'node_id':'a'}],[{'from':'a','to':'a','kind':'data','epoch_lag':1}])

@pytest.mark.parametrize('event',['authority','binding','membership','expiry','retraction','release'])
def test_control_events_invalidate_downstream(event):
    dirty=dirty_closure(build_graph(REG),['control.'+event])
    assert 'package.compose' in dirty and 'deriv.baseline@2.0.0' in dirty

def test_derivation_to_signal_dependency_exists():
    dirty=dirty_closure(build_graph(REG),['hiring.role'])
    assert 'hiring.velocity' in dirty and 'tag.growth_posture' in dirty and 'signal:GROWING_PAIN' in dirty

def test_unknown_graph_endpoint_rejected():
    with pytest.raises(ValueError,match='UNREGISTERED_GRAPH_ENDPOINT'):topological_order([{'node_id':'a'}],[{'from':'a','to':'bad','kind':'data','epoch_lag':0}])

def test_graph_edge_removed_is_rejected(bundle):
    p=bundle/'registry/dependency-graph.json';d=read_json(p);d['edges'].pop();p.write_text(json.dumps(d))
    with pytest.raises(Invalid,match='GRAPH_INCOMPLETE|TOPOLOGICAL'):validate_bundle(bundle,verify_release=False)

def test_multiple_vendors_do_not_overwrite_one_another():
    a=read_json(ROOT/'instances/facts/001.json');b=copy.deepcopy(a);b.update(fact_id='fact.second',claim_slot='["hubspot"]',object={'entity_id':'hubspot','class_id':'crm'})
    assert claim_key(a)!=claim_key(b) and len(current_per_source([a,b]))==2

def test_sources_are_not_collapsed():
    a=read_json(ROOT/'instances/facts/001.json');b=copy.deepcopy(a);b.update(fact_id='fact.second',source='other-source')
    assert claim_key(a)==claim_key(b) and observation_key(a,'snap')!=observation_key(b,'snap') and len(current_per_source([a,b]))==2

def test_unknown_does_not_replace_known_observation():
    a=read_json(ROOT/'instances/facts/001.json');b=copy.deepcopy(a);b.update(fact_id='fact.unknown',state='UNKNOWN',object=None,observed_at='2026-09-14T00:00:00Z')
    assert next(iter(current_per_source([a,b]).values()))[0]['fact_id']==a['fact_id']

def test_equal_time_conflict_preserved():
    a=read_json(ROOT/'instances/facts/001.json');b=copy.deepcopy(a);b.update(fact_id='fact.absent',state='NOT_FOUND',object=None)
    assert len(next(iter(current_per_source([a,b]).values())))==2

@pytest.mark.parametrize('count',[0,1,29])
def test_cohort_minimum_eligible_not_member_count(count):
    f=flow('baseline');assert evaluate(f,{'values':[True]*count+[None]*50})['state']=='UNKNOWN'

def test_cohort_unknown_not_negative():
    r=evaluate(flow('baseline'),{'values':[True]*30+[None]*5});assert r['outputs']['cohort.baseline']['share']==1 and r['outputs']['cohort.baseline']['n_excluded']==5

def test_percentile_ties_midrank():
    r=evaluate(flow('percentile'),{'values':[5]*30,'target':5});assert r['outputs']['cohort.percentile']['raw_percentile']==50

def test_zero_variance_outlier_abstains():
    assert evaluate(flow('outlier'),{'values':[5]*30,'target':10})['reason']=='ZERO_VARIANCE'

def test_trend_requires_three_windows():
    assert evaluate(flow('trend'),{'shares':[0.2,0.4],'eligible_counts':[30,30]})['state']=='UNKNOWN'

def test_reply_windows_and_repeated_sends():
    f=flow('angle_performance');fx=features('angle_performance');r=evaluate(f,fx)
    assert r['outputs']['angle.performance']['reply_rate']==0.2
    fx['exposures']+=copy.deepcopy(fx['exposures']);assert evaluate(f,fx)==r

def test_immature_exposures_do_not_count():
    fx=features('angle_performance');fx['exposures'][0]['age_days']=1
    assert evaluate(flow('angle_performance'),fx)['state']=='UNKNOWN'

def test_bounced_exposures_do_not_count_as_deliverable():
    fx=features('angle_performance');fx['exposures'][0]['bounced']=True
    assert evaluate(flow('angle_performance'),fx)['state']=='UNKNOWN'

def test_cross_angle_contamination_excluded():
    fx=features('angle_performance');other=copy.deepcopy(fx['exposures'][0]);other['angle_id']='other';other['exposure_id']='second.touch';fx['exposures'].append(other)
    assert evaluate(flow('angle_performance'),fx)['state']=='UNKNOWN'

def test_wilson_known_symmetry():
    lo,hi=wilson(5,10);assert lo<0.5<hi and abs(lo+hi-1)<1e-12

def test_missing_icp_is_unknown_not_C():
    assert evaluate(flow('icp_fit'),{})['state']=='UNKNOWN'

def test_size_band_spanning_boundary_abstains():
    assert evaluate(flow('size_class'),{'employees':{'minimum':5,'maximum':20}})['state']=='UNKNOWN'

def test_readiness_is_not_deployed_maturity():
    assert evaluate(flow('automation_maturity'),{'verification':{'manual_only':False,'lowcode_in_use':False,'custom_integrations_live':False,'agents_live':False}})['state']=='UNKNOWN'

def test_readiness_unknown_not_false():
    assert evaluate(flow('ai_surface_readiness'),{'dimensions':[False,False,None]})['state']=='UNKNOWN'

def test_irregular_growth_is_not_stable():
    assert evaluate(flow('growth_posture'),{'pairs':[[10,20],[20,10]]})['state']=='UNKNOWN'

def test_one_year_is_not_recurrence():
    assert evaluate(flow('seasonality'),{'months':[10]*12})['state']=='UNKNOWN'

def test_location_optional_unknown_is_safe():
    assert evaluate(flow('location_model'),{'locations':[{'location_id':'a','region':'AZ','country':'US'}]})['outputs']['tag.location_model']=='single_location'

@pytest.mark.parametrize('html,expected',[
 ('<script src="https://assets.calendly.com/a.js"></script>',True),
 ('<script src = "//assets.calendly.com/a.js"></script>',True),
 ('<script src="https://assets.calendly.com.bad.test/a.js"></script>',False),
 ('<script src="https://bad.test/assets.calendly.com/a.js"></script>',False),
 ('<!-- <script src="https://assets.calendly.com/a.js"></script> -->',False),
 ('<a href="https://assets.calendly.com/">blog</a>',False),
 ('<footer><script src="https://assets.calendly.com/a.js"></script></footer>',False),
])
def test_parsed_asset_matching(html,expected):
    assert match(REG['fingerprints'][0],html)==expected


def test_open_upper_employee_band_is_known():
    assert evaluate(flow('size_class'),{'employees':{'minimum':200,'maximum':None}})['outputs']['tag.size_class']=='upper_200_plus'

def test_conflicting_duplicate_exposure_is_not_silently_counted():
    fx=features('angle_performance');other=copy.deepcopy(fx['exposures'][0]);other['replied']=not other['replied'];fx['exposures'].append(other)
    with pytest.raises(ValueError,match='CONFLICTING_EXPOSURE_ID'):evaluate(flow('angle_performance'),fx)


def test_unregistered_kernel_version_rejected():
    f=flow('baseline');f['algorithm_version']='99.0.0'
    with pytest.raises(ValueError,match='UNREGISTERED_ALGORITHM_VERSION'):evaluate(f,features('baseline'))
