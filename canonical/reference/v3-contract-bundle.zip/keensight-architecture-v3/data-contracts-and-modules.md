# Data contracts and modules

The normative overview is [SYSTEM.md](SYSTEM.md), the exact field contracts are generated under `schemas/`, and program/content definitions are generated under `registry/`.

Record groups are Subject/Scope/Snapshot/Coverage; Fact/Evidence/Execution; RunPlan/RunManifest/RunCompletion; Signal/AdjudicationRecord; OutreachPackage; CohortSnapshot; JournalEvent/JournalMutation; OutboxItem/DeliveryGate; Exposure/OutcomeEvent; BudgetReservation/RepairAttempt.

There is no private integration inference from a public NOT_FOUND fact. Source TTL is an integer number of seconds, not a loosely parsed duration string. Object values are validated per predicate. All observations, including reproducible ones, have an exact evidence path. Claim identity includes the predicate's multiplicity slot and scope; source-specific observation identities remain separate.

Refer to [implementation ports](docs/IMPLEMENTATION_PLAN.md), [persistence semantics](docs/PERSISTENCE_AND_OPERATIONS.md), [graph semantics](docs/GRAPH_MODEL.md) and [UML](docs/DIAGRAMS.md). This file intentionally does not repeat a second divergent set of field definitions.
