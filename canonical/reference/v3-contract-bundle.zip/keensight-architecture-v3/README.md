# KeenSight architecture v3

Start with [SYSTEM.md](SYSTEM.md). This is a revised, fixture-only architecture and contract bundle, not a deployed application. No old-code migration or repository changes are included.

## Reproduce

Python 3.11 or later is the intended implementation floor; the bundled test report records the exact interpreter used for this verification. Install the pinned design-time dependencies:

```bash
python -m pip install -r requirements.txt
python generate_structures.py --check
python validate.py
python -m pytest -q
```

To intentionally edit the design:

```bash
# Edit authoring/*.json, contract_schema.py or example_catalog.py.
python generate_structures.py
python validate.py
python -m pytest -q
```

Generation and validation are deliberately separate. Validation never regenerates or repairs an invalid disk file before examining it. `--check` verifies that generated outputs match the authored source. Runtime library code is not executed merely by importing catalog.py.

## Source ownership

| Path | Authority |
|---|---|
| `authoring/*.json` | Human-edited content, policies, typed derivations and fixed numerical fixtures |
| `contract_schema.py` | Normative record schemas |
| `example_catalog.py` | Synthetic contract-level examples |
| `contract_tools/` | Executable reference kernels and graph/identity/matcher utilities |
| `schemas/`, `registry/`, `instances/` | Generated; do not edit as source |
| `docs/`, `SYSTEM.md` | Architectural decisions and implementation contracts |
| `diagrams/*.mmd` | Editable Mermaid source; diagrams are not rendered binaries |
| `reports/`, `VALIDATION.md` | Actual verification output and scope boundaries |

This replaces the inaccurate idea of one catalog file authoring schemas, policies, fixtures and examples at once. Each concern now has one explicit owner; generated outputs cannot silently become competing definitions.

All Sources in this release are fixture-only; production is disabled. A schema or test pass is not a real promotion record, live-detection accuracy estimate or operational readiness sign-off.
