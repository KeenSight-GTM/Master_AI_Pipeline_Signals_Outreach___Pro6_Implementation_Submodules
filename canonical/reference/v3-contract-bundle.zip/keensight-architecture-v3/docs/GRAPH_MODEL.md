# Graph model and recomputation

## Three different graphs, three different contracts

| Graph | Nodes and edges | Cycle policy | Storage role |
|---|---|---|---|
| Computation dependency graph | Predicates, materializers, derivations, signal types, adjudication, packages and control triggers | Acyclic within one evaluation epoch, including self-edges; feedback must carry a positive declared epoch lag | Compiled execution plan and invalidation index |
| Provenance graph | Immutable snapshots, observations, executions, adjudications and packages connected by actual consumed/produced IDs | Acyclic instance-level causality; no future/self-parent evidence | Audit, explanation, authority/freshness ancestry and retraction fan-out |
| Entity relationship graph | Organizations, locations, people, vendors, account/site bindings and typed relationships | Business relationships may legitimately cycle; canonical-alias redirects may not | Attribution and identity projection, not the scheduler |

Do not put all edges into one undifferentiated NetworkX graph and call it the system. NetworkX is optional as an in-memory implementation behind the graph interfaces. The initial compiler uses standard-library topological sorting and deterministic adjacency lists; no graph database, ToG, HippoRAG or RAG retrieval system is required to run this architecture.

## Compile, do not infer

`registry/dependency-graph.json` is compiled from typed `bindings`, `outputs`, signal expressions and explicit materializer dependencies. No input/output is extracted from English descriptions or by regular expressions. The compiler verifies references, source/output agreement, predicate back-links, duplicate nodes, edge kinds, legal epoch lags and phase ordering.

Self-dependencies are rejected, not dropped. Multinode cycles and control-edge cycles are rejected with the graph disconnected from runtime. A stable lexicographic topological order provides deterministic tie-breaking between independent tasks. Parallel edges of different kinds are retained; identical edges may be deduplicated.

## Evaluation epochs

An epoch has one sealed RunManifest: frozen as_of, an external-input journal cutoff, exact registry and policy hashes, code identity and identity version. All historical queries use that cut. Current-epoch outputs are visible through the run workspace only after their producing stage commits. A worker may not read unrelated new external facts simply because they arrived after the input cut.

Acquisition must finish or explicitly close incomplete work before the evaluation manifest is sealed. A provisional acquisition plan pins source/model/prompt/policy versions first; the final evaluation cut is sealed after capture. Replaying recorded outputs does not re-fetch a website or ask an LLM the same question again.

Verification requested during adjudication is bounded and external. Its returned evidence becomes input to a new epoch, or a newly sealed child evaluation with its own manifest; it cannot silently mutate a frozen computation. Prior run outputs used as historical observations are explicitly time-bounded.

## Phase order

0. External captures, source assertions, identity/scope registrations and control state at the frozen input cut.
1. Base descriptors and temporal summaries: verified maturity, business/industry projection, size, location, DNS camp, public readiness, sales state, stack, data quality, hiring/content/change rate, marker removal, seasonality.
2. Higher-level account descriptors: growth and marketing maturity, using phase-1 summaries.
3. ICP prioritization and cohort materialization/statistics, using frozen membership and metric eligibility.
4. Candidate signal evaluation, including signal-to-signal prerequisites in topological order.
5. Final adjudication: resolved, unresolved or operationally suppressed.
6. Grounded claim composition, maturity/offer checks, package approval.
7. Transactional outbox and externally gated dispatch.
8. Outcome normalization/materialization from captured operational facts.
9. Mature angle performance statistics.

The exact phase DAG is compiled, not assumed from this numbered narrative. Edges may connect nodes within a phase when the graph remains acyclic. Source facts that are unavailable at the frozen cut yield UNKNOWN; optional modules do not fabricate data to make a phase complete.

## Feedback is across epochs

Outcome statistics and dispatch events affect the next evaluation, not the decision that created their own exposure. The graph encodes `angle.performance -> control.next_epoch` with `epoch_lag=1`, then `control.next_epoch -> package.compose` in that next epoch. Replaying epoch e therefore never uses its future replies to select epoch e's copy.

A one-epoch-lag edge is legal only for an explicitly declared feedback edge. Dropping every cyclic edge or marking arbitrary cycles as delayed is not allowed. The initial scheduler supports lag 0 and lag 1 only; more complex recurrence requires a new tested contract.

## Invalidation is more than new facts

Dirty triggers include assertions, retractions, authority demotion/promotion, binding and identity changes, cohort membership changes, TTL expiry, changed registry releases and mature outcomes. The initial graph intentionally over-invalidates selected subgraphs on broad control events; this is safer than an incomplete optimized watch graph.

The scheduler computes downstream closure, orders dirty nodes, and creates a deduplicated task per `(tenant, run, node, input-set hash, release)`. Multiple causes for one task coalesce. A worker commits outputs only if its generation token and dependencies still match. Otherwise its result is retained as a superseded execution but is not promoted into current views or packages.

Time alone can invalidate evidence. The runtime must schedule explicit expiry and outcome-maturation work; waiting for another site capture is not sufficient. These are durable operational jobs, not edges invented from the wall clock during replay.

## Rebuild and graph acceptance

Rebuild means replaying the ordered journal into empty projections, retaining original event identities, recorded times, input references and result values. Compare a canonical logical export of rows ordered by declared primary keys. Do not compare physical SQLite bytes, row placement, WAL files or indexes.

Required runtime acceptance tests include mid-transaction interruption, replay at historical cutoffs, out-of-order event time, partial retries, stale generation tokens, entity split/rebind invalidation, authority demotion and exact expiry boundaries. The supplied suite tests compiler/invalidation reference behavior and instance provenance cycles; it does not claim that the persistent scheduler or journal has been implemented.
