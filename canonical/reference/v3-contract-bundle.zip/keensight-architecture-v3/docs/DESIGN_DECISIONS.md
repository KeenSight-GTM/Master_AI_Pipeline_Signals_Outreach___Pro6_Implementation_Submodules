# Design decisions — architecture v3

Status: proposed architecture; executable contract/reference tests are included; production services are not implemented. The release is fixture-only. The selected audit findings are #1, #3, #4, #5, #6, #7 (graphs generally), #8, #10, #14 and #15 from the September 14, 2026 review.

## 1. Keep the simple architecture

Start with a modular monolith, one transactional database, one content-addressed blob interface, and one bounded worker queue. Acquisition, fact admission, graph scheduling, signal evaluation, adjudication and composition are module boundaries, not a requirement for separately deployed services. One writer owns journal sequence allocation and transactional projections. Network work happens outside write transactions. API/LLM adapters and outbound delivery are ports.

Existing code may be reused behind these ports after passing the new contracts. There is no legacy data migration, legacy schema compatibility promise, old-to-new feature mapping project, or repository deployment in this revision.

## 2. Separate observations from accepted claims

A `Fact` is an immutable observation/assertion, not a mutable entity attribute. Its `fact_id` identifies that observation. Its claim key is:

`(tenant_id, subject_id, predicate, claim_slot, scope_id)`

`claim_slot` is `_` for a singleton. For a set-valued predicate it is the canonical tuple of that predicate's `identity_paths`. For example, Calendly and HubSpot have different vendor slots. A specifically targeted absence retains its query slot even though its object is null. `scope_id` references an immutable logical scope definition, not a single capture. A new capture reuses the same scope only when resources, sampling policy, capture mode, binding and predicate eligibility are comparable; a scope revision gets a new ID.

Observation identity additionally includes source version and immutable capture/input identity. Sources are not collapsed into one row: they remain independently available for corroboration or conflict. A newer Google observation cannot erase a Microsoft observation merely because both use `vendor.present`.

Current state is a projection, not a journal mutation. First group by claim and source, exclude retracted entries, then select the newest eligible known observations by observation time. Preserve equal-time contradictory evidence for adjudication. UNKNOWN records describe missing knowledge or execution failure and never overwrite a still-fresh known claim. Expiry can still make that known claim ineligible. For mutually exclusive singleton values from competing sources, abstain until the declared adjudication policy selects a supported result.

For a class-level negative such as no registered scheduler marker, the slot refers to the checked class, not an invented missing vendor. Class negatives and entity positives are different claims; the query resolver must reject a negative if eligible positive evidence contradicts it in the same declared scope/window. Absence may never supersede unrelated vendor slots.

## 3. Public absence is not private absence

`NOT_FOUND` means: the declared detector/source completed its declared check against the declared resources and capture mode and did not find the target. It does not mean that the target cannot exist elsewhere.

A NOT_FOUND fact must cite a Coverage record. That record identifies the source version, predicate(s), scope, completed resources, successful untruncated snapshots, time and detector release. The snapshots must actually cover those resources. Policy exclusions, failed API pagination, robots exclusions, timeouts, inaccessible routes, unrendered JavaScript and truncated captures are incomplete coverage for any check that requires them. They produce UNKNOWN or a narrower explicitly defined scope.

Raw-HTML homepage non-detection never becomes rendered-DOM absence. A completed list of sampled pages is not proof that an entire website or organization has been exhaustively searched. Coverage is coverage of the registered sampling/check plan only.

`integration.present` is a public-marker predicate. The new `integration.connection.verified` carries a specific from/to pair, connected Boolean and authorized verification method. `BOOKING_CRM_DISCONNECT` and `LOWCODE_UNUSED_CAPACITY` require verified connectivity evidence, not public non-detection. A false Boolean in a completed authorized check is OBSERVED, not UNKNOWN.

Completed AI probes similarly use OBSERVED with `cited: false`; failed or unexecuted probes are UNKNOWN. The retained `SEO_AI_INVISIBLE` identifier is restricted to a scoped probe opportunity, not a universal invisibility claim. Full multi-engine/probe-set aggregation remains a separately versioned protocol, not an implied capability of the initial release.

## 4. Ground the entire message

Approval is not a spelling or placeholder check. The composer creates a message from a closed claim AST plus vetted neutral questions. Each factual clause has an operator with a typed evidence contract, a source-kind restriction, a same-subject/tenant check, eligibility rules, and a deterministic renderer. Approval verifies that the entire rendered string equals the output of those operators. Fixed template text is included in that boundary.

The executable initial renderer supports `observed_vendor` plus the single neutral `booking_crm_handoff` question. Other claim operator names are reserved in the schema but deliberately fail closed until their renderer and evidence fixtures are implemented. Freeform LLM copy may be a DRAFT suggestion; it cannot become APPROVED through a generic truthiness check or by citing one unrelated fact.

Approved synthetic example:

> I noticed a Calendly embed on your site. How are booked appointments passed into your CRM today?

Rejected example with the same evidence:

> Your booking and CRM still don't talk.

A verified report renderer must say who reported what or what authorized system check observed, rather than silently converting a report into omniscient truth. A cohort renderer must disclose its measured peer population, denominator and window. These renderers are specified extension points, not implemented in this release.

## 5. Maturity is not opportunity or a public footprint

`LOWCODE_ACTIVE` observes a public footprint; it does not prove a paid subscription or operational usage. `AGENTIC_READY` is an opportunity hypothesis, not evidence of a deployed agent. Neither alone establishes L1 or L3.

`ops.automation.verified` records explicit authorized API or human verification. The maturity kernel maps verified low-code use to L1, verified custom integrations to L2, and verified agents plus custom integrations to L3. L0 requires explicit manual-only verification, not silence. Contradictory verification abstains.

A package stores `current_rung` and `offered_rung` separately. A normal approved package requires offered = current + 1. UNKNOWN maturity abstains from rung-specific outreach. L3 has no L4 in this ladder: it also abstains from a one-up offer rather than clamping back to L3. A future L3 optimization/expansion offer must be an explicit different policy with its own tests.

This change is necessary to provide an internally valid approval fixture under the selected stricter validation, even though the earlier review listed example-readiness separately as #2.

## 6. Keep companions attached to executions

There are no unregistered pseudo-predicates such as `direction (good/bad)` or `regulated_regimes[]`. Only declared `outputs` become facts. Scores, basis lists, peak months, selected windows, metric diagnostics and exclusion details live in a typed `Execution.details` object or a typed statistic value. Other rules may consume only registered predicates or explicitly declared artifact contracts, never a string scraped from explanatory notes.

The business-type flow emits both `tag.business_type` and `tag.industry`. Every flow has a producing Source registration. Every predicate declares its value schema, cardinality, identity, permitted states, allowed source tiers, visibility and reverse `derived_by` links.

## 7. Facts stay auditable without making every fact a huge document

Every fact, including reproducible fingerprints and derived facts, references an Evidence record. A raw fact's Evidence points to immutable snapshots and locators. A derived fact points to the exact Execution, input facts/signals and retained input-artifact identities. A digest without the retrievable input set is insufficient.

Authority and freshness apply transitively. A computation cannot promote candidate parents or refresh stale input evidence by running again. At a fixed evaluation cut, effective eligibility is the conjunction of the output's own source policy and the eligible ancestry. A current safety veto may later invalidate a queued package even though historical replay under the original manifest remains reproducible.

The old two-hop statement becomes a navigation guarantee: package -> claim -> directly cited evidence fact. The complete provenance DAG may be deeper and must remain traversable. Never discard intermediate lineage simply to satisfy an artificial hop count.

## 8. Numeric defaults are policy, not empirical findings

The thresholds, weights, response window, cohort coverage floor and retention intervals in this release are concrete proposed defaults. They can now be implemented consistently and tested at boundaries. They have not been calibrated on real sites, validated by a gold set, or approved as a legal retention determination.

The release's active authority values are simulated values for DESIGN_TEST fixtures. All Sources are explicitly `fixture_only`; production is disabled in policy. They do not document real promotions. Real source/policy promotion requires independent fixture sets, shadow evaluation, recorded reviewer decisions and separate calibration gates.
