# Cohorts and outcome measurement

All numeric defaults in this document are proposed versioned policy. Statistical output must disclose what was measured; neither a schema nor a minimum sample threshold establishes market representativeness or causal effectiveness.

## Cohort population and eligibility

Freeze the CohortDefinition, subject canonicalization version, input journal cut, as_of, membership list, measurement scope, source/protocol versions and comparison window. Count canonical organizations rather than pages, sources, observations or locations unless the definition explicitly declares a location-level unit. A target organization must not appear in its own peer comparison, including through an alias or branch represented by the same canonical organization.

`n_members` is the number of peers matching the membership definition after target exclusion. `n_eligible` is the number with one usable measurement. `n_excluded = n_members - n_eligible`; exclusion reasons are recorded in the retained measurement artifact. Conflicting, UNKNOWN, stale, unbound, candidate-authority, missing-period and incomparable measurements are excluded, never turned into zeros.

An observed public presence counts as Boolean true. A valid scope-proven NOT_FOUND may count as false only for a predicate whose measured property is that public marker. It is never a false value for a private-capability measurement. Authorized API or human Boolean false is OBSERVED false for that distinct predicate.

A statistic is usable only when `n_eligible >= 30` and `n_eligible / n_members >= 0.80`, after target exclusion. These are explicit initial policy floors, not an assertion that 30 observations is universally adequate. Below either floor, emit an UNKNOWN result with a reason and counts; do not silently omit the computation or emit an artificial baseline of zero.

## Baselines

For a Boolean measurement, `share = successes / n_eligible`. Store counts and a Wilson interval with z = 1.96, plus window and membership/measurement hashes through the associated Execution and CohortSnapshot. The interval describes the sampled eligible measurements; it does not repair selection bias or prove independent sampling. Repeated organizations, common-source syndication and clustering must be considered in the evaluation harness.

Allowed research framing identifies the denominator and scope: for example, a measured fraction of comparable eligible peer sites had a public scheduler marker in the registered capture window. It is not a claim that every peer runs a corresponding internal automation.

## Percentiles

One metric value per eligible peer, same provider definition, units, form factor and compatible period. The empirical midrank is:

`raw_percentile = 100 * (count(peer_value < target) + 0.5 * count(peer_value == target)) / n_eligible`.

For a lower-is-better metric, `quality_percentile = 100 - raw_percentile`; otherwise quality and raw rank coincide. A low quality percentile is consistently worse, avoiding the original ambiguity for latency metrics. Missing target values abstain. The target is excluded before computing the peer distribution.

## Outliers

Use population mean and population standard deviation on the eligible peer distribution. `z = (target - mean) / population_stddev`; flag when `abs(z) >= 2.0`. A zero-variance distribution yields UNKNOWN, not infinity or an arbitrary outlier. Store high/low direction separately from any good/bad interpretation; only a metric's registered direction supplies that interpretation.

## Trends

Use at least three complete adjacent 90-day UTC windows in the initial reference policy. These are fixed windows, not mislabeled calendar quarters. Use a balanced panel: the same canonical peer IDs must be eligible in every window under comparable versions/scopes. Require the eligible-count and coverage floor in each original window, then the minimum-size floor again after the balanced-panel intersection.

Compute per-window shares for that same panel and fit ordinary least-squares slope against equally spaced window indices. Store slope-per-window, all window definitions, panel hash and panel size. This measures a prevalence trend, not an adoption event rate. Calling it adoption requires explicit per-entity transitions and censoring rules in another definition. Changing membership creates a new population series or a recomputed comparable history; it must not be mistaken for behavioral change.

The reference kernel receives an already balanced, eligibility-checked panel summary. Constructing and checking the actual panel IDs is a future materializer responsibility, not something numerical arrays alone can prove.

## Outcome facts are not all HUMAN

Provider delivery events are API assertions. Attributable human classifications and notes are HUMAN facts. LLM reply-intent or sentiment classifications are candidate LLM facts until reviewed/calibrated under the relevant policy. The gateway must not disguise model classifications as human outcomes.

Persist raw event evidence, provider/event identifiers, provider message ID, package revision, recipient, account, initial exposure, angle, service line, experiment assignment, occurred_at and received_at. Deduplicate by `(tenant, provider, provider_event_id)`; reject a repeated ID with a conflicting payload rather than incrementing counts.

Join events to a known accepted send through provider message ID. Unmatched events remain quarantined. An operational send retry must not create another exposure for the same provider-accepted message.

## Measurement units and windows

The initial descriptive unit is the initial recipient assignment within an experiment/campaign measurement window. Repeated sequence messages for that unit do not multiply its denominator. Preserve the underlying exposures, but aggregate any eligible reply/meeting/unsubscribe to the initial assignment. Cross-angle contamination within a unit is reported and excluded from angle comparison unless a separate attribution design explicitly handles it.

Freeze `as_of`. Select initial accepted exposures in `[as_of - 90 days, as_of)`. An exposure becomes mature after 14 complete days. Only qualifying outcomes within `[initial_accepted_at, initial_accepted_at + 14 days)` enter the reply/meeting metric. An event arriving late may correct the statistic in a new journaled computation if its event time is inside that window. A reply whose event time is outside the window is retained but does not retroactively change this metric definition.

The initial reply/meeting denominator is **mature, provider-accepted units not known to have terminally bounced**, not a claim of verified inbox delivery. UNKNOWN acceptance does not enter it. When a provider supplies verified delivery, store and report that separately. Required report fields include accepted, mature, eligible, bounced, contaminated and pending counts.

`reply_rate = units with qualifying reply / eligible units`.

`meeting_rate = units with qualifying meeting / eligible units`.

`bounce_rate = terminally bounced mature units / mature accepted units`.

`unsubscribe_rate = unsubscribing mature units / mature accepted units`.

Require at least 10 eligible mature units for the initial descriptive angle-performance output. Include a Wilson reply interval and the exact denominator. Immature units are pending, not failures. Report bounce and unsubscribe guardrails alongside replies to avoid rewarding an angle through denominator exclusion.

## Causal and operational boundaries

The supplied statistic explicitly sets `causal: false`. Differential reply rates among selectively targeted accounts are descriptive. Automated promotion based on such differences is not enabled. A causal experiment requires a separately recorded randomization unit, arm allocation, fixed outcome window, target population, holdout, guardrails and an analysis policy appropriate for repeated recipients/accounts.

Provider reconciliation, durable event ingestion, true exposure materialization, randomized evaluation and auto-promotion are not implemented in this design-time bundle. The executable kernel tests cover minimum sizes, UNKNOWN exclusion, tie percentiles, zero variance, immature/bounced unit exclusion, repeat-unit deduplication and contamination behavior on normalized fixtures.
