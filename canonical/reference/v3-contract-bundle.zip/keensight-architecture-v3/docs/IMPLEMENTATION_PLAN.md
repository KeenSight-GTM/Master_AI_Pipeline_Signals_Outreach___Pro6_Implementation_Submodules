# Proposed code and implementation order

## Proposed package layout

```text
keensight/
  contracts/       # Record types, schema adapters and typed policy registries
  registry/        # Immutable release loader, linker and DAG compiler
  storage/         # BlobStore, journal writer, migrations, replay and projections
  acquisition/     # Planner, adapters, destination policy and budget-aware capture
  extraction/      # Prose/JSON-LD/asset extraction and explicit subject bindings
  knowledge/       # Fact admission, claim identity, provenance and current views
  reasoning/       # Selector materializers, kernels, cohorts, signals, adjudication
  orchestration/   # Run sealing, generation tokens, tasks and dirty closure
  commercial/      # Claim AST, deterministic renderers, audience/rung approval
  delivery/        # Outbox, latest-state gate and provider reconciliation
  outcomes/        # Webhook normalization, exposure joins and mature metrics
  governance/      # Promotion, calibration, tenant permissions and retention
```

This is one application and deployment initially. Packages express dependency boundaries and ownership, not a mandate for twelve network services. All side effects pass through explicit ports. Pure evaluators receive a frozen context and return typed results; they do not read the current clock, query arbitrary tables or call providers.

## Stage 1 — durable truth

Implement content storage, typed journal append, hash-chain verification, idempotency, subject/scope registrations, fact/evidence admission and rebuildable claim projections. Include the command schemas for retractions, authority changes, collisions and identity changes. Finish the RunPlan/RunManifest lifecycle and frozen input cut before permitting derived decisions.

Acceptance: crash injection at each append boundary; duplicate same-payload return; conflicting idempotency-key rejection; all declared content references valid; multivalued vendor retention; separate-source history; UNKNOWN does not overwrite; deterministic logical replay; retention tombstone survives restore.

## Stage 2 — conservative captured-evidence slice

Implement the closed fingerprint interface over stored captures, coverage construction and source registration. Reuse scanner extraction code only after proving the new source/scope/evidence contract. The bundled Calendly detector helper is a design-time example, not a complete replacement for an acquisition scanner or subject resolver.

Acceptance: target in an asset, blog link, agency-owned embed, comment, lookalike domain, redirects, protocol-relative URL, rendered-only marker, truncated page and partial scan. Store ambiguity rather than attributing an agency marker to the customer by default.

## Stage 3 — deterministic reasoning and invalidation

Implement selector/materializer contracts, durable task graph, reference-kernel integration, typed signal expressions, actual confound rules and adjudication. Source authority/freshness must be checked through all ancestry. Compile the full graph before activating any affected release.

Acceptance: every required missing/UNKNOWN input abstains; self/multinode/provenance cycles fail; live control changes invalidate dependent work; stale generation tokens cannot publish; execution output agrees with registered output/value contracts. Add real fact-to-feature fixtures for every flow; numerical kernel fixtures alone do not cover materialization.

## Stage 4 — grounded local packages

Implement the initial vendor-observation claim renderer and neutral question, audience/contact eligibility, verified rung selection and immutable approval revisions. Disable actual provider dispatch. Use this stage to review real examples and calibrate signals separately from copy quality.

Acceptance: unsupported fixed text rejected, same-account references only, source/candidate/expiry checks, private-disconnection claim requires authorized evidence, one-up rule obeyed, unknown/L3 terminal maturity abstains, missing required slots fails, all claims retain original evidence.

## Stage 5 — cohorts, delivery and outcome measurement

Implement frozen membership and eligibility materializers; then the outbox/gate/provider reconciliation workflow and deduplicated outcomes. Schedule maturation and expiry tasks explicitly. Keep descriptive performance separate from experimentation and automated promotion.

Acceptance: UNKNOWN excluded without becoming zero; target/alias excluded from peers; minimum eligible size/coverage enforced; balanced panels checked by ID; provider timeouts do not trigger duplicate blind sends; DNC checked at dispatch; reply timing, late events and event deduplication correct; every reported denominator auditable.

## Reuse rule

Old scanner, storage, provider or signal code can implement a new port. Reuse is approved by conformance tests, not by matching a filename or preserving an old workflow. The new architecture owns its contracts. No legacy migration or old schema compatibility work is scheduled here.
