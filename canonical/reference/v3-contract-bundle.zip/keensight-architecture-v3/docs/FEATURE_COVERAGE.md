# Feature coverage and retained design scope

This revision retains the original 79 fact identifiers and all 18 signal identifiers while correcting unsafe meanings and adding explicit contracts. Keeping an identifier does not preserve an unsafe claim: public absence and private verification are now separate.

## Eight added predicates

| Predicate | Purpose |
|---|---|
| `integration.connection.verified` | Specific connectivity outcome from authorized API or attributable human verification |
| `ops.automation.verified` | Verified operational ladder evidence, separate from public tool presence |
| `ops.sales.verified` | Verified booking/CRM/connection state for sales maturity |
| `company.business_model` | Explicit controlled business-model input for the dual-output classifier |
| `acquisition.coverage` | Typed operational completeness/freshness summary for descriptor inputs |
| `change.template.stable` | Explicit comparability evidence for marker-removal analysis |
| `outreach.exposure` | Actual accepted exposure identity, separate from outcomes |
| `location.data.consistency` | Measured inconsistency across explicitly checked locations |

## Original disambiguation workstreams

These retained workstreams are implementation requirements, not 16 completed runtime systems. Existing notes are preserved below only for traceability; current truth/copy/absence rules in SYSTEM.md override earlier assumptions.

| Number | Workstream | Implementation posture |
|---|---|---|
| 1 | Subject resolution | Contract/reference coverage where selected; full runtime integration not certified |
| 2 | Entity resolution (crosswalk) | Contract/reference coverage where selected; full runtime integration not certified |
| 3 | Collision rules | Contract/reference coverage where selected; full runtime integration not certified |
| 4 | Predicate identity (relationship truthing) | Contract/reference coverage where selected; full runtime integration not certified |
| 5 | Claim-type constraints | Contract/reference coverage where selected; full runtime integration not certified |
| 6 | Binding status | Contract/reference coverage where selected; full runtime integration not certified |
| 7 | Attribution qualifier | Contract/reference coverage where selected; full runtime integration not certified |
| 8 | Corroboration independence | Contract/reference coverage where selected; full runtime integration not certified |
| 9 | Coverage semantics | Contract/reference coverage where selected; full runtime integration not certified |
| 10 | State gate (UNKNOWN) | Contract/reference coverage where selected; full runtime integration not certified |
| 11 | Filter stack | Contract/reference coverage where selected; full runtime integration not certified |
| 12 | Confound checks (adjudication) | Contract/reference coverage where selected; full runtime integration not certified |
| 13 | Conflict & precedence | Contract/reference coverage where selected; full runtime integration not certified |
| 14 | Rung assignment rubric | Contract/reference coverage where selected; full runtime integration not certified |
| 15 | Abstention & verification queue | Contract/reference coverage where selected; full runtime integration not certified |
| 16 | Copy-layer enforcement | Contract/reference coverage where selected; full runtime integration not certified |

## Material capability boundary

The new bundle contains no live API credentials, source calls, CRM writes or sends. It does not claim a finished cross-account research product, model-calibrated ontology mapper, production collision-resolution system, real multi-engine AI visibility measurement or full golden-site evaluation. The current graph and predicate contracts allow these to be added deliberately; unsupported inputs remain UNKNOWN.
