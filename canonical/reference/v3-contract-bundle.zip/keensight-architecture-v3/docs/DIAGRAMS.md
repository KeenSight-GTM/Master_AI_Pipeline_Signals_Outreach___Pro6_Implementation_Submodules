# Dataflow and UML views

Editable Mermaid sources for the proposed implementation. These are architecture diagrams, not evidence that runtime services exist.

## 01 Dataflow

```mermaid
flowchart TB
    R[Authored contracts and policies] --> L[Fail-closed linker and graph compiler]
    L --> P[Pinned acquisition plan]
    P --> A[Bounded acquisition and adapters]
    A --> B[Immutable content-addressed captures]
    A --> C[Explicit coverage results]
    B --> M[Seal evaluation RunManifest and input cut]
    C --> M
    M --> X[Extraction and subject binding]
    X --> F[Typed Fact admission and provenance]
    F --> J[Append-only journal]
    J --> V[Rebuildable views plus committed run workspace]
    V --> D[Dependency scheduler]
    D --> D1[Base and temporal derivations]
    D1 --> D2[Higher-level descriptors]
    D2 --> CO[Frozen cohort membership and eligible measurements]
    CO --> S[Signal evaluation]
    D1 --> S
    S --> AD[Adjudication]
    AD -->|UNRESOLVED| Q[Bounded verification queue]
    Q -->|Evidence for a new epoch| A
    AD -->|RESOLVED and eligible| CL[Grounded claims and neutral questions]
    CL --> O[Immutable approved package revision]
    O --> OB[Transactional outbox]
    OB --> G[Latest-state delivery gate]
    G -->|Allowed| SEND[Provider dispatch and reconciliation]
    G -->|Veto| HOLD[Cancelled or invalidated]
    SEND --> EV[Deduplicated exposure and outcome evidence]
    EV --> J
    EV --> PERF[Mature descriptive angle performance]
    PERF -. Next epoch only .-> D
```

## 02 Domain Model

```mermaid
classDiagram
    class RunManifest {
        +run_id
        +as_of
        +journal_offset
        +registry_release
        +policy_release
        +identity_version
        +epoch
    }
    class SourceDefinition {
        +source_id
        +tier
        +authority
        +ttl_seconds
        +fixture_only
    }
    class PredicateDefinition {
        +predicate
        +value_schema
        +cardinality
        +identity_paths
        +allowed_tiers
        +derived_by
    }
    class Subject {
        +tenant_id
        +subject_id
        +kind
        +canonical_subject_id
    }
    class Scope {
        +scope_id
        +kind
        +resources
        +capture_mode
        +binding_version
    }
    class Fact {
        +fact_id
        +claim_slot
        +state
        +object
        +observed_at
        +evidence_id
    }
    class Evidence {
        +evidence_id
        +snapshot_ids
        +input_fact_ids
        +input_signal_ids
        +execution_id
        +coverage_id
    }
    class Snapshot {
        +snapshot_id
        +resource_uri
        +content_hash
        +captured_at
        +truncated
    }
    class Coverage {
        +coverage_id
        +planned_resources
        +completed_resources
        +status
        +detector_release
    }
    class DerivationExecution {
        +execution_id
        +flow_id
        +input_set_hash
        +output_fact_ids
        +window
        +details
    }
    class ClaimView {
        +tenant_subject_predicate_slot_scope
        +accepted_fact_ids
        +conflict_status
    }
    Subject "1" --> "*" Scope
    Subject "1" --> "*" Fact
    Fact "*" --> "1" PredicateDefinition
    Fact "*" --> "1" SourceDefinition
    Fact "*" --> "1" Scope
    Fact "*" --> "1" RunManifest
    Fact "1" --> "1" Evidence
    Evidence --> Snapshot : captured support
    Evidence --> Coverage : required for NOT_FOUND
    Evidence --> DerivationExecution : required for derived
    DerivationExecution --> Fact : consumes and emits IDs
    ClaimView --> Fact : references without overwriting
```

## 03 Component Interfaces

```mermaid
classDiagram
    class AcquisitionPort {
        <<interface>>
        +capture(plan, reservation) CaptureResult
    }
    class BlobStore {
        <<interface>>
        +put_verified(bytes, policy) BlobRef
        +get_authorized(ref) bytes
    }
    class JournalStore {
        <<interface>>
        +append(command, idempotency_key) Commit
        +replay(cut, projector) ProjectionDigest
    }
    class RegistryLinker {
        +load_release(hash) LinkedRegistry
        +compile_graph(registry) ExecutionPlan
    }
    class FactService {
        +admit(assertion, provenance) Fact
        +resolve_claim(key, cut) ClaimView
    }
    class DependencyScheduler {
        +invalidate(cause) TaskSet
        +commit_if_current(token, outputs) Commit
    }
    class DerivationEngine {
        +materialize_inputs(flow, cut) ExecutionInputs
        +evaluate(flow, inputs) Result
    }
    class SignalEngine {
        +evaluate(definition, eligible_facts) Signal
    }
    class Adjudicator {
        +resolve(signals, policy) AdjudicationRecord
    }
    class ClaimComposer {
        +render(claims, questions) GroundedText
        +approve(package, evidence) PackageRevision
    }
    class DeliveryPort {
        <<interface>>
        +send(item, gate) ProviderReceipt
        +reconcile(dedup_key) DeliveryState
    }
    class OutcomeService {
        +ingest(event) ExposureUpdate
        +materialize(window) OutcomeUnits
    }
    AcquisitionPort --> BlobStore
    FactService --> JournalStore
    FactService --> RegistryLinker
    DependencyScheduler --> RegistryLinker
    DependencyScheduler --> DerivationEngine
    DerivationEngine --> FactService
    SignalEngine --> FactService
    Adjudicator --> SignalEngine
    ClaimComposer --> Adjudicator
    ClaimComposer --> FactService
    DeliveryPort --> ClaimComposer
    OutcomeService --> JournalStore
```

## 04 Evaluation Sequence

```mermaid
sequenceDiagram
    participant A as Acquisition
    participant B as Blob store
    participant J as Journal
    participant R as Run coordinator
    participant D as DAG scheduler
    participant F as Fact service
    participant S as Signals and adjudication
    participant C as Claim composer
    A->>B: Persist and verify raw captures
    A->>J: Append snapshot and coverage records
    R->>J: Seal external-input cut and RunManifest
    R->>D: Compile pinned execution plan
    D->>F: Admit observations with subject and provenance
    F->>J: Append immutable facts and evidence
    D->>F: Commit ordered derivation and cohort outputs
    D->>S: Evaluate eligible facts and typed prerequisites
    alt Missing evidence or confound
        S->>J: Record UNRESOLVED and bounded verification request
    else Supported signal
        S->>J: Record RESOLVED adjudication
        S->>C: Supply resolved IDs and verified maturity
        C->>F: Verify same subject, freshness, authority and ancestry
        C->>C: Render complete claim AST and one-up offer
        C->>J: Commit approved revision and local outbox item
    end
```

## 05 Delivery Sequence

```mermaid
sequenceDiagram
    participant W as Outbox worker
    participant DB as Transactional store
    participant G as Delivery gate
    participant P as Provider
    participant O as Outcome service
    W->>DB: Lease one business-deduplicated send
    W->>G: Evaluate latest safety state and evidence eligibility
    alt Veto or expired package
        G->>DB: Record gate and cancel item
    else Allowed
        G->>DB: Record gate and dispatch identity
        W->>P: Send with provider idempotency key when supported
        alt Provider acceptance known
            P-->>W: Provider message ID
            W->>DB: Record accepted exposure exactly once locally
        else Acceptance uncertain
            W->>DB: Mark UNKNOWN_DELIVERY
            W->>P: Reconcile, do not blindly retry
        end
    end
    P-->>O: Delivery or reply event
    O->>DB: Deduplicate event ID and retain evidence
    O->>DB: Join exposure or quarantine unmatched event
    O->>DB: Schedule mature measurement for a later epoch
```

## 06 Package State

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> APPROVED: All claim and eligibility gates pass
    DRAFT --> DRAFT: Missing evidence or unsupported copy
    APPROVED --> INVALIDATED: Expiry, retraction, demotion, rebind or safety veto
    APPROVED --> NEW_REVISION: Copy or evidence changes
    NEW_REVISION --> DRAFT
    INVALIDATED --> [*]
    note right of APPROVED
        Sending and outcomes are separate
        outbox and exposure states.
        Approval is not proof of sending.
    end note
```

## 07 Graph Separation

```mermaid
flowchart LR
    subgraph Dependency_DAG[Computation graph]
        P[Typed input] --> D[Derivation]
        D --> S[Signal]
        S --> A[Adjudication]
        A --> C[Package]
        O[Outcome metric epoch e] -. lag 1 .-> N[Selection epoch e plus 1]
    end
    subgraph Provenance_DAG[Evidence graph]
        B[Snapshot bytes] --> F[Fact observation]
        F --> X[Execution record]
        X --> Y[Derived observation]
        Y --> Z[Grounded claim]
    end
    subgraph Entity_graph[Identity and business relationships]
        ORG[Organization] --> LOC[Location]
        ORG --> V[Vendor]
        V --> ORG
    end
```
