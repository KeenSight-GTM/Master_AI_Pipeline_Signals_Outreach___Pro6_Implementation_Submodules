# Persistence, execution safety and operations

These are decisions for the proposed implementation. The schemas and reference tests do not constitute a running database, message sender, privacy service, budget ledger or LLM gateway.

## Storage layout

Use a content-addressed BlobStore port and one transactional database initially. The database owns journal entries, immutable record payload references, evidence joins, scopes/identity versions, execution records, operational outbox/outcomes, budget reservations and rebuildable projections. SQLite is the initial local deployment target; changing the storage adapter must preserve transactions and semantics, not require redesigning facts.

Store raw public captures, API bodies, LLM input/output and human evidence as classified blobs. Hash plaintext bytes inside the authorized boundary for deduplication, but encrypt sensitive content under tenant/retention-scoped keys. Do not deduplicate private content across tenants. Expose opaque references to other modules, not arbitrary filesystem paths or external fetch URLs.

The design-time fixtures use local `content_ref` paths and verify byte length and SHA-256. Production content references are BlobStore keys, resolved only through that port. A schema-valid content reference is not permission to read an arbitrary path.

## Journal envelope and payloads

One append order per tenant; allocate monotonically increasing `sequence` values within the same database transaction as the immutable event record and its atomic local effects. Do not derive order from wall-clock timestamps. Preserve both `occurred_at` and `recorded_at`.

The event envelope has event ID, tenant, sequence, schema version, typed kind, immutable record reference, payload hash, occurred/recorded times, idempotency key, previous-event hash, event hash and originating run. Facts carry their OBSERVED/NOT_FOUND/UNKNOWN state; separate journal kinds for every fact subtype are unnecessary. Executions, cohort computations and operational events still have explicit event kinds.

Hash the canonical envelope without `event_hash`, including the previous hash and payload hash. Production canonicalization is RFC 8785 JCS, not an assumption that Python `json.dumps(sort_keys=True)` is a cross-language canonicalizer. Money/budget accounting uses integer micro-units; NaN and infinity are forbidden. Event IDs and recorded times are assigned once and persisted; replay does not generate replacements.

The release manifest has a separate documented exact-file-byte hashing algorithm (`sha256-path-nul-filehash-lf-v1`). It is not presented as a JCS implementation. A production JCS implementation and the journal hash-chain writer still need their own test vectors and runtime implementation.

## Append transaction

1. Validate the command, source/predicate/schema release, tenant, scope and idempotency key.
2. Write a content blob to a temporary object, flush it, verify its hash, and atomically finalize it. An orphan finalized blob is recoverable by conservative garbage collection; never commit a reference to an unfinalized blob.
3. Start the database write transaction and reserve the next tenant sequence.
4. Append immutable records/evidence, the journal event and transactional local outbox/control effects.
5. Commit. Publish asynchronous work only after the durable commit, using the outbox rather than an uncommitted in-memory notification.

A duplicate idempotency key with the same payload returns the original event/result. The same key with a different payload fails. Projection updates may be in that transaction initially; later asynchronous projectors use atomic `(view state, last applied sequence)` commits. Workers may replay; visible effects must be idempotent.

## Indexes and keys

Journal: unique `(tenant_id, sequence)` and `(tenant_id, idempotency_key)`.

Observations: primary `fact_id`, plus `(tenant, subject, predicate, claim_slot, scope, source, observed_at)` index. Do not create a unique index on `(subject, predicate)`.

Evidence/executions: immutable ID keys; all input/output joins stored and indexed both directions. Input-set digests supplement the retained member list, not replace it.

Scopes/bindings: immutable versions, with canonicalization redirects and explicitly bounded assignments. Entity split/rebind commands contain exact fact assignments; no automatic redistribution based only on names. Historical manifests retain their identity view, while new computations invalidate affected subjects/cohorts/packages.

## Replay and schema evolution

Retain original events. Add versioned deterministic upcasters for older envelope/payload versions; never rewrite source events to fit the latest schema. A projection checkpoint includes input offset, projector version, registry/policy/identity versions and canonical logical-row digest. Deleting all projection tables and replaying the journal must reproduce that logical digest.

Replay uses recorded computation outputs and references, not live providers, model calls, current TTL clocks or current registry HEAD. Recomputing a new policy on old evidence is a new run and new executions, not historical replay.

Restore tests must include privacy tombstones and current safety controls. A backup restore must not reintroduce erased content into active indexes or outbound queues.

## Durable jobs and generation tokens

Use a unique task key `(tenant, run, node, input-set hash, registry release)` and a generation token. Acquire a bounded lease; compute outside the write transaction; commit only if the token is still current. Lost leases and crash retries may repeat computation, but not duplicate committed outputs. Record stale/cancelled executions for audit without promoting their results.

Commit all outputs of a multi-output derivation atomically. A business-type flow must not publish tag.business_type while silently dropping its declared tag.industry output. UNKNOWN executions still produce a typed reason and observation state so consumers can abstain and diagnostics can explain why.

## Transactional outbox and delivery gate

Approval creates an immutable package revision. A rewrite creates a new revision with `supersedes_package_id`; it does not edit already approved evidence or text in place. Signal invalidation, expiry, retraction, DNC, changed binding or authority can invalidate a queued revision.

Outbox deduplication uses the business send identity `(tenant, campaign, recipient, sequence step, occurrence)`, not only package revision. Editing copy must not accidentally authorize another send for the same scheduled touch. The outbox records leases, attempts and provider message IDs separately from package approval state.

Immediately before dispatch, recompute a DeliveryGateRecord from the latest safety/control view: DNC and unsubscribe, stage/cooldown, current binding, source demotion, freshness, package revision, contact eligibility, provider limits and the applicable send window. Frozen historical evidence does not override a current safety veto.

The database and an email provider do not share an atomic transaction. Use provider idempotency where available. A timeout after a potentially accepted send becomes UNKNOWN_DELIVERY; reconcile by the provider message/dedup identity rather than blindly retrying. Without provider support or a reliable reconciliation path, abstain from automatic retries. Never claim exactly-once network delivery merely because the local database transaction is atomic.

A suppression event arriving after dispatch has begun may be too late to recall an accepted message. Record the exact gate/dispatch ordering and attempt provider cancellation where supported; do not claim that local locking can unsend an external action.

## Budget ledger

Reserve a conservative maximum cost before launching work, atomically against shared tenant/run/source budgets. Parallel workers cannot each read the same remaining balance and spend it independently. Use integer monetary micro-units and separately bounded request/token/render counters.

The adapter submits its worst-case bounded cost and task ID. Reject dispatch when a conservative maximum cannot be determined or reserved. Settle actual cost once. Release unused reservation only after confirmed non-execution or completed reconciliation. An uncertain paid request remains reserved/charged conservatively; an expiring worker lease does not prove the provider incurred no cost.

Retries and JSON-repair calls consume the same ledger and concurrency controls. A network failure becomes a typed task outcome and UNKNOWN where relevant, never a negative observation.

## LLM gateway and JSON repair

Treat captures, pages and model output as untrusted data. Tasks have explicit purpose, schema, permitted evidence, bounded inputs, provider/model/prompt identifiers, token/output caps and budget reservations. The model cannot grant authority, issue arbitrary tools, choose new sources, or promote its own output.

Persist raw request and response before parsing. Preserve refusal, truncation, provider errors and malformed text. Attempt at most two repairs under the declared policy: first a deterministic syntax-only repair where safe; second a bounded model repair if enabled and budgeted. Store each original/repair artifact, parent reference, mode, validation errors and cost. Never overwrite the original response.

A repair may correct syntax, not invent missing evidence, replace unknown values with guesses, or change an entity to make validation pass. Repaired data must pass structural, reference, subject, state, coverage, authority and semantic checks. If meaning changed or required evidence is missing, record an invalid result and abstain. An LLM source remains an LLM source after repair.

## Security, access and retention

Use tenant-scoped authorization at all ports; restrict who can promote registries, merge/split subjects, add HUMAN facts, approve packages and enable delivery. Credentials stay outside prompts, blobs and ordinary journal payloads. Fetchers need explicit destination/scheme policies, redirect handling, private-address protection and resource limits. Untrusted page text cannot modify these policies.

Default retention proposals are 365 days for public captures, 180 days for business-confidential evidence and 30 days for sensitive raw content, subject to an explicitly approved purpose/retention policy. These are engineering defaults for review, not legal advice or a compliance claim.

Do not put sensitive free text directly into a permanent append-only envelope. Store it behind encrypted/erasable references. Retention expiry or authorized deletion produces a minimal tombstone, removes/crypto-erases content and invalidates dependent evidence/copy. Backups and exported packages need corresponding deletion/expiry handling. A retained hash can still be sensitive and is not automatically anonymous.

## Runtime acceptance gates still to implement

Crash-consistent append, hash-chain verification, database rebuild, backup restore, event upcasting, concurrent budget overspend prevention, bounded repair recording, generation-token races, provider timeout reconciliation, late unsubscribe invalidation and privacy erasure require runtime implementations and integration tests. They are specified here rather than silently counted as completed by the design-time test suite.
