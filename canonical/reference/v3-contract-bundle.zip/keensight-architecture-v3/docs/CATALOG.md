# Current predicate catalog

Generated review view of the 87 typed predicate registrations. The original 79 identifiers are retained; eight explicit evidence/operational predicates were added. Detailed value schemas are in registry/predicates.json.

| Predicate | Domain | Multiplicity | Value shape | Visibility |
|---|---|---|---|---|
| `vendor.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `vendor.mentioned` | technology | set | object | PUBLIC_MEASUREMENT |
| `booking.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `crm.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `esp.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `chat.widget.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `payment.processor.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `automation.platform.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `integration.present` | technology | set | object | PUBLIC_MEASUREMENT |
| `website.platform` | technology | set | object | PUBLIC_MEASUREMENT |
| `vendor.certification_badge` | technology | singleton | object | PUBLIC_MEASUREMENT |
| `dns.mx.provider` | infrastructure | set | object | PUBLIC_MEASUREMENT |
| `dns.dmarc.policy` | infrastructure | singleton | enum: none, quarantine, reject | PUBLIC_MEASUREMENT |
| `dns.spf.includes` | infrastructure | set | object | PUBLIC_MEASUREMENT |
| `dns.txt.verification` | infrastructure | set | object | PUBLIC_MEASUREMENT |
| `dns.cname.service` | infrastructure | set | object | PUBLIC_MEASUREMENT |
| `cert.new_subdomain` | infrastructure | singleton | object | PUBLIC_MEASUREMENT |
| `api.public.present` | infrastructure | singleton | object | PUBLIC_MEASUREMENT |
| `app.mobile.present` | infrastructure | singleton | object | PUBLIC_MEASUREMENT |
| `status.page.present` | infrastructure | singleton | object | PUBLIC_MEASUREMENT |
| `schema.jsonld.present` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `schema.jsonld.types` | content/seo | singleton | array | PUBLIC_MEASUREMENT |
| `schema.subject_binding` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `content.page_inventory` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `content.velocity_band` | content/seo | singleton | enum: dormant, low, medium, high | PUBLIC_MEASUREMENT |
| `content.type.present` | content/seo | set | object | PUBLIC_MEASUREMENT |
| `seo.cwv.field` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `seo.indexation` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `seo.keyword.footprint` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `seo.authority` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `seo.local.presence` | content/seo | singleton | object | PUBLIC_MEASUREMENT |
| `seo.ai_visibility.cited_in` | content/seo | set | object | PUBLIC_MEASUREMENT |
| `industry.vertical` | identity | singleton | enum: dental, legal, medspa, hvac, roofing, electrical, accounting, veterinary, it_services, real_estate, other | PUBLIC_MEASUREMENT |
| `industry.subvertical` | identity | singleton | object | PUBLIC_MEASUREMENT |
| `company.self_claim` | identity | singleton | object | ATTRIBUTED_REPORT |
| `company.locations` | identity | singleton | array | PUBLIC_MEASUREMENT |
| `company.geo` | identity | singleton | object | PUBLIC_MEASUREMENT |
| `company.age_band` | identity | singleton | object | PUBLIC_MEASUREMENT |
| `identity.binding_evidence` | identity | singleton | object | INTERNAL_ONLY |
| `firmo.employee_band` | firmographics | singleton | object | PUBLIC_MEASUREMENT |
| `firmo.revenue_band` | firmographics | singleton | object | PUBLIC_MEASUREMENT |
| `firmo.ownership` | firmographics | singleton | enum: independent, pe_owned, franchisee, subsidiary | PUBLIC_MEASUREMENT |
| `firmo.funding` | firmographics | set | object | PUBLIC_MEASUREMENT |
| `person.contact` | firmographics | singleton | object | INTERNAL_ONLY |
| `review.metrics` | reputation | set | object | PUBLIC_MEASUREMENT |
| `review.response_ratio` | reputation | set | object | PUBLIC_MEASUREMENT |
| `competitor.presence` | reputation | singleton | object | PUBLIC_MEASUREMENT |
| `hiring.role` | growth | set | object | PUBLIC_MEASUREMENT |
| `hiring.velocity` | growth | singleton | object | PUBLIC_MEASUREMENT |
| `ads.activity` | growth | singleton | object | PUBLIC_MEASUREMENT |
| `news.events` | growth | set | object | PUBLIC_MEASUREMENT |
| `headcount.history` | growth | singleton | array | PUBLIC_MEASUREMENT |
| `change.page.delta` | change | singleton | object | PUBLIC_MEASUREMENT |
| `tech.rollback` | change | set | object | PUBLIC_MEASUREMENT |
| `change.velocity` | change | singleton | enum: low, medium, high | PUBLIC_MEASUREMENT |
| `outreach.outcome` | operational | set | object | INTERNAL_ONLY |
| `crm.note` | operational | singleton | object | INTERNAL_ONLY |
| `account.stage` | operational | singleton | enum: prospect, contacted, qualified, customer, closed_lost | INTERNAL_ONLY |
| `suppression.dnc` | operational | singleton | object | INTERNAL_ONLY |
| `tag.automation_maturity` | derived_tags | singleton | enum: L0, L1, L2, L3 | INTERNAL_ONLY |
| `tag.marketing_maturity` | derived_tags | singleton | enum: NONE, BASIC, ACTIVE, SOPHISTICATED | INTERNAL_ONLY |
| `tag.growth_posture` | derived_tags | singleton | enum: GROWING, STABLE, CONTRACTING | INTERNAL_ONLY |
| `tag.platform_camp` | derived_tags | singleton | enum: google_stack, microsoft_stack, mixed | INTERNAL_ONLY |
| `tag.regulated_vertical` | derived_tags | singleton | enum: healthcare_review, legal_review, financial_review, none | INTERNAL_ONLY |
| `tag.size_class` | derived_tags | singleton | enum: micro_1_9, sme_10_49, mid_50_199, upper_200_plus | INTERNAL_ONLY |
| `tag.location_model` | derived_tags | singleton | enum: single_location, regional_chain, franchise, national | INTERNAL_ONLY |
| `tag.industry` | derived_tags | singleton | enum: dental, legal, medspa, hvac, roofing, electrical, accounting, veterinary, it_services, real_estate, other | INTERNAL_ONLY |
| `tag.business_type` | derived_tags | singleton | enum: local_service, mobile_service, ecommerce, saas, agency, professional_services, restaurant, healthcare_practice, retail, franchise_unit, manufacturing, nonprofit | INTERNAL_ONLY |
| `tag.ai_surface_readiness` | derived_tags | singleton | enum: not_ready, partial, ready | INTERNAL_ONLY |
| `tag.stack_complexity` | derived_tags | singleton | enum: unified_suite, light_stack, assembled_stack | INTERNAL_ONLY |
| `tag.sales_maturity` | derived_tags | singleton | enum: manual, assisted, automated | INTERNAL_ONLY |
| `tag.seasonality` | derived_tags | singleton | enum: seasonal, steady | INTERNAL_ONLY |
| `tag.icp_fit` | derived_tags | singleton | enum: A, B, C | INTERNAL_ONLY |
| `tag.data_quality` | derived_tags | singleton | enum: shallow, standard, deep | INTERNAL_ONLY |
| `cohort.baseline` | cohort | singleton | object | COHORT_ONLY |
| `cohort.percentile` | cohort | singleton | object | COHORT_ONLY |
| `cohort.trend` | cohort | singleton | object | COHORT_ONLY |
| `cohort.outlier` | cohort | singleton | object | COHORT_ONLY |
| `angle.performance` | derived | singleton | object | COHORT_ONLY |
| `integration.connection.verified` | operational | set | object | ATTRIBUTED_REPORT |
| `ops.automation.verified` | operational | singleton | object | INTERNAL_ONLY |
| `ops.sales.verified` | operational | singleton | object | INTERNAL_ONLY |
| `company.business_model` | operational | singleton | enum: local_service, mobile_service, ecommerce, saas, agency, professional_services, restaurant, healthcare_practice, retail, franchise_unit, manufacturing, nonprofit | PUBLIC_MEASUREMENT |
| `acquisition.coverage` | operational | singleton | object | INTERNAL_ONLY |
| `change.template.stable` | operational | singleton | boolean | PUBLIC_MEASUREMENT |
| `location.data.consistency` | operational | singleton | object | PUBLIC_MEASUREMENT |
| `outreach.exposure` | operational | set | object | INTERNAL_ONLY |
