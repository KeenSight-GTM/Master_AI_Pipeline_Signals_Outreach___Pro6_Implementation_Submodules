# Architecture v3 changes

This revision supersedes the original archive as the proposed current architecture; it does not overwrite the original upload or modify either GitHub repository.

Selected findings addressed: #1, #3, #4, #5, #6, #7, #8, #10, #14 and #15. SYSTEM.md provides the traceability table. Changes also repair the synthetic package's prerequisite/maturity inconsistency as a necessary consequence of stricter approval validation, and include a limited safer fingerprint reference helper without claiming a full production scanner fix.

The architecture stays a modular monolith initially. Facts remain append-only observations with exact evidence. Claim keys now include multiplicity and scope. Public absence is scoped, private integration requires authorized verification, and whole-message copy is a closed grounded composition. Typed program dependencies replace English token extraction. Computation/provenance/entity graphs have different cycle contracts. Cohort and outcome denominators and windows are explicit. Journal/outbox/budget/repair/security/retention decisions are written down as runtime contracts.

The current review view is Markdown plus JSON, not a silently stale copy of the old workbook. Authoring ownership is split explicitly among contracts, content/policies and fixtures; generated directories are not authoritative editable sources.

All thresholds and simulated authority states remain proposed/unvalidated for production. The validation report separates executed design-time evidence from unimplemented runtime acceptance tests. No legacy migration is planned; old code may be reused behind the new ports.
