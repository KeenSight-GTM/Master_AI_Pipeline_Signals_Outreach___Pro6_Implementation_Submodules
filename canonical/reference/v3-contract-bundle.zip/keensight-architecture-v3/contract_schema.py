"""Normative Draft-07 contracts. No runtime/network side effects."""
from copy import deepcopy

S = {"type": "string", "minLength": 1}
ID = {"type": "string", "pattern": r"^[A-Za-z0-9][A-Za-z0-9_.:@/-]*$"}
UTC = {"type": "string", "format": "date-time", "pattern": r"Z$"}
HASH = {"type": "string", "pattern": "^sha256:[a-f0-9]{64}$"}
N = {"type": "number"}
INT = {"type": "integer", "minimum": 0}
BOOL = {"type": "boolean"}
PROB = {"type": "number", "minimum": 0, "maximum": 1}
VERSION = {"type": "string", "pattern": r"^[0-9]+\.[0-9]+\.[0-9]+$"}

def enum(*values): return {"enum": list(values)}
def arr(item=S, minimum=0, unique=False):
    d={"type":"array", "items":deepcopy(item), "minItems":minimum}
    if unique: d["uniqueItems"]=True
    return d

def obj(fields, required=None):
    return {"type":"object","additionalProperties":False,"properties":deepcopy(fields),
            "required":list(fields) if required is None else required}

def nullable(s): return {"anyOf":[deepcopy(s), {"type":"null"}]}

def schema(name, body):
    return {"$schema":"http://json-schema.org/draft-07/schema#", "$id":f"https://keensight.local/v3/{name}.schema.json", "title":name, **body}

WINDOW = obj({"start":UTC,"end":UTC})
VALUE = {"type":["string","number","boolean","object","array","null"]}
KV = {"type":"object", "additionalProperties":S}
KINDS = enum("ORG","LOCATION","PERSON","BRAND","COHORT","ANGLE")
STATE = enum("OBSERVED","NOT_FOUND","UNKNOWN")
AUTH = enum("candidate","active","deprecated")
SCHEMAS = {}

def add(name, body): SCHEMAS[name]=schema(name,body)

add("predicate", obj({
    "predicate":ID, "domain":S, "description":S, "subject_kinds":arr(KINDS,1,True),
    "allowed_tiers":arr(enum("FINGERPRINT","API","LLM","HUMAN","DERIVED","COHORT"),1,True),
    "states":arr(STATE,1,True), "cardinality":enum("singleton","set","series"),
    "identity_paths":arr(S,0,True), "value_schema":{"type":"object"},
    "absence_allowed":BOOL, "visibility":enum("PUBLIC_MEASUREMENT","ATTRIBUTED_REPORT","INTERNAL_ONLY","COHORT_ONLY"),
    "derived_by":arr(ID,0,True)}))
add("source", obj({"source_id":ID,"tier":enum("FINGERPRINT","API","LLM","HUMAN","DERIVED","COHORT"),
    "authority":AUTH,"fixture_only":BOOL,"claim_type":enum("EMBEDDED","SELF_CLAIMED","OBSERVED_RUNTIME","HUMAN_REPORTED","INFERRED","TAXONOMY_DERIVED"),
    "reproducible":BOOL,"confidence_prior":nullable(PROB),"ttl_seconds":{"type":"integer","minimum":1},
    "emits":arr(ID,1,True),"independence_group":S}))
add("subject",obj({"subject_id":ID,"tenant_id":ID,"kind":KINDS,"canonical_subject_id":ID}))
add("scope",obj({"scope_id":ID,"subject_id":ID,"tenant_id":ID,"kind":enum("element","page","site","authorized_system","probe_set","cohort","operational"),
    "resources":arr(S,1,True),"capture_mode":enum("raw_html","rendered_dom","api_response","human_record","derived","operational"),
    "binding":enum("DIRECT","INFERRED","UNBOUND"),"binding_version":S}))
add("snapshot",obj({"snapshot_id":ID,"scope_id":ID,"content_hash":HASH,"content_ref":S,"resource_uri":S,"media_type":S,"byte_count":INT,
    "captured_at":UTC,"status":enum("OK","ERROR","TIMEOUT","POLICY_EXCLUDED"),"truncated":BOOL,
    "retention_policy":S,"classification":enum("PUBLIC","BUSINESS_CONFIDENTIAL","SENSITIVE")}))
add("coverage",obj({"coverage_id":ID,"scope_id":ID,"source_id":ID,"predicate_ids":arr(ID,1,True),
    "planned_resources":arr(S,1,True),"completed_resources":arr(S,1,True),"snapshot_ids":arr(ID,1,True),
    "status":enum("COMPLETE","INCOMPLETE"),"checked_at":UTC,"detector_release":HASH}))
add("evidence",obj({"evidence_id":ID,"snapshot_ids":arr(ID,0,True),"input_fact_ids":arr(ID,0,True),
    "input_signal_ids":arr(ID,0,True),"execution_id":nullable(ID),"coverage_id":nullable(ID),
    "locator":S,"independence_groups":arr(S,1,True)}))
add("fact",obj({"fact_id":ID,"tenant_id":ID,"subject_id":ID,"predicate":ID,"claim_slot":S,
    "scope_id":ID,"object":VALUE,"state":STATE,"source":ID,"observed_at":UTC,"evidence_id":ID,"run_id":ID}))
SCHEMAS["fact"]["allOf"]=[
    {"if":{"properties":{"state":{"enum":["UNKNOWN","NOT_FOUND"]}},"required":["state"]},
     "then":{"properties":{"object":{"type":"null"}}}},
    {"if":{"properties":{"state":{"const":"OBSERVED"}},"required":["state"]},
     "then":{"properties":{"object":{"not":{"type":"null"}}}}}]

# Typed boolean expression; comparisons never infer UNKNOWN as false/absence.
TEST=obj({"kind":enum("fact"),"predicate":ID,"state":STATE,"path":S,"comparison":enum("exists","eq","ne","lt","lte","gt","gte","in"),
    "value":VALUE,"scope_kind":enum("element","page","site","authorized_system","probe_set","cohort","operational","any")},
    ["kind","predicate","state","path","comparison","value","scope_kind"])
SIGTEST=obj({"kind":enum("signal"),"signal_type":ID,"status":enum("RESOLVED")})
EXPR={"oneOf":[TEST,SIGTEST,obj({"kind":enum("all","any"),"args":arr({"$ref":"#/definitions/expr"},1)})]}
add("signal-type",obj({"signal_type":ID,"pack":ID,"service_lines":arr(enum("ai_workflow","lowcode","agentic","ai_seo"),1,True),
    "condition":{"$ref":"#/definitions/expr"},"requires_coverage":BOOL,"meaning":S,"copy_policy":enum("QUESTION_ONLY","SCOPED_MEASUREMENT","ATTRIBUTED_REPORT"),
    "phase":INT,"confound_policy":S}))
SCHEMAS["signal-type"]["definitions"]={"expr":EXPR}
add("signal-pack",obj({"pack_id":ID,"authority":AUTH,"signal_types":arr(ID,1,True)}))
add("signal",obj({"signal_id":ID,"tenant_id":ID,"subject_id":ID,"signal_type":ID,"status":enum("RESOLVED","UNRESOLVED","SUPPRESSED","CANDIDATE"),
    "reason":nullable(enum("CONFOUND","CONFLICT_TIE","THIN_DATA","UNKNOWN_INPUT","DNC","PRIOR_REJECTION","RECENT_OUTREACH","STAGE")),
    "input_fact_ids":arr(ID,0,True),"input_signal_ids":arr(ID,0,True),"source_pack":ID,"computed_at":UTC,"run_id":ID}))
SCHEMAS["signal"]["allOf"]=[
    {"if":{"properties":{"status":{"enum":["RESOLVED","CANDIDATE"]}}},"then":{"properties":{"reason":{"type":"null"}}}},
    {"if":{"properties":{"status":{"const":"UNRESOLVED"}}},"then":{"properties":{"reason":enum("CONFOUND","CONFLICT_TIE","THIN_DATA","UNKNOWN_INPUT")}}},
    {"if":{"properties":{"status":{"const":"SUPPRESSED"}}},"then":{"properties":{"reason":enum("DNC","PRIOR_REJECTION","RECENT_OUTREACH","STAGE")}}}]
add("adjudication-pack",obj({"pack_id":ID,"authority":AUTH,"algorithm":enum("independent_max_decay_v1"),
    "half_life_seconds":{"type":"integer","minimum":1},"tie_epsilon":PROB,"minimum_margin":PROB,
    "null_prior":enum("UNRESOLVED"),"tie":enum("UNRESOLVED"),"on_confound":enum("UNRESOLVED")}))
add("adjudication-record",obj({"adjudication_id":ID,"subject_id":ID,"source_pack":ID,"input_signal_ids":arr(ID,1,True),
    "resolved":arr(ID,0,True),"unresolved":arr(ID,0,True),"suppressed":arr(ID,0,True),"computed_at":UTC}))

BINDING=obj({"name":ID,"kind":enum("predicate","artifact"),"ref":ID,"path":S,
    "reducer":enum("latest","history","count_distinct","complete_series","cohort_snapshot","outcome_aggregate"),
    "required":BOOL})
add("derivation-flow",obj({"flow_id":ID,"algorithm":ID,"algorithm_version":VERSION,"authority":AUTH,
    "phase":INT,"bindings":arr(BINDING,1),"outputs":arr(ID,1,True),"parameters":{"type":"object"},
    "window_policy":obj({"mode":enum("NONE","FIXED_DAYS","CALENDAR_MONTHS"),"length":INT,"segment_length":INT,"timezone":enum("UTC"),"interval":enum("[start,end)"),"complete_segments":BOOL}),"missing_policy":enum("UNKNOWN"),"details_schema":{"type":"object"},
    "description":S,"feature_schema":{"type":"object"},"parameter_schema":{"type":"object"},"policy_status":enum("PROPOSED_UNCALIBRATED"),"fixtures":arr(obj({"label":S,"features":{"type":"object"},"expect":{"type":"object"}}),2)}))
add("execution",obj({"execution_id":ID,"flow_id":ID,"run_id":ID,"subject_id":ID,"scope_id":ID,
    "input_fact_ids":arr(ID,0,True),"input_signal_ids":arr(ID,0,True),"input_artifact_ids":arr(ID,0,True),
    "input_set_hash":HASH,"output_fact_ids":arr(ID,1,True),"effective_at":UTC,"window":WINDOW,
    "status":enum("OBSERVED","UNKNOWN"),"reason":nullable(S),"details":{"type":"object"}}))
add("cohort-definition",obj({"cohort_id":ID,"authority":AUTH,"member_filters":arr(obj({"predicate":ID,"equals":VALUE}),1),
    "measurement_predicate":ID,"measurement_path":S,"direction":enum("higher_is_better","lower_is_better","descriptive"),
    "minimum_eligible":{"type":"integer","minimum":2},"minimum_coverage":PROB,"minimum_trend_windows":{"type":"integer","minimum":3},
    "refresh_seconds":{"type":"integer","minimum":1},"window_seconds":{"type":"integer","minimum":1},
    "exclude_target":BOOL,"missing_policy":enum("exclude_and_report"),"percentile":enum("midrank"),
    "outlier":enum("population_z"),"outlier_threshold":{"type":"number","exclusiveMinimum":0}}))
add("cohort-snapshot",obj({"cohort_snapshot_id":ID,"definition_id":ID,"run_id":ID,"member_subject_ids":arr(ID,1,True),
    "eligible_subject_ids":arr(ID,0,True),"excluded_subject_ids":arr(ID,0,True),"input_fact_ids":arr(ID,0,True),
    "as_of":UTC,"window":WINDOW,"journal_offset":INT,"membership_hash":HASH,"measurement_hash":HASH}))

# In the initial implementation, approved copy is a closed composition, not arbitrary prose.
add("angle-pack",obj({"angle_pack_id":ID,"authority":AUTH,"requires":{"$ref":"#/definitions/expr"},
    "maturity_policy":enum("ONE_UP_OR_ABSTAIN"),"required_slots":arr(ID,0,True),
    "claim_operators":arr(enum("observed_vendor","attributed_report","scoped_absence","cohort_statistic"),1,True),
    "question_ids":arr(ID,1,True),"service_lines":arr(enum("ai_workflow","lowcode","agentic","ai_seo"),1,True)}))
SCHEMAS["angle-pack"]["definitions"]={"expr":EXPR}
CLAIM=obj({"operator":enum("observed_vendor","attributed_report","scoped_absence","cohort_statistic"),"fact_id":ID})
add("outreach-package",obj({"package_id":ID,"revision":{"type":"integer","minimum":1},"supersedes_package_id":nullable(ID),"tenant_id":ID,"subject_id":ID,"angle_pack":ID,"adjudication_id":ID,
    "maturity_fact_id":ID,"current_rung":enum("L0","L1","L2","L3"),"offered_rung":enum("L1","L2","L3"),
    "claims":arr(CLAIM,1),"question_id":ID,"rendered_text":S,"slots":{"type":"object","additionalProperties":ID},
    "status":enum("DRAFT","APPROVED","INVALIDATED"),"run_id":ID,"approved_at":nullable(UTC),
    "mode":enum("DESIGN_TEST","SHADOW","PRODUCTION")}))
add("fingerprint",obj({"fingerprint_id":ID,"authority":AUTH,"emits":ID,"entity_id":ID,
    "operators":arr(obj({"op":enum("asset_host_suffix"),"host":S,"tags":arr(enum("script","iframe","link"),1,True)}),1),
    "tests":obj({"must_fire":arr(S,1,True),"must_not_fire":arr(S,1,True)})}))

EDGE=obj({"from":ID,"to":ID,"kind":enum("data","control","membership","binding","expiry","authority","retraction","release","feedback"),
    "epoch_lag":{"type":"integer","minimum":0,"maximum":1}})
NODE=obj({"node_id":ID,"kind":enum("predicate","signal","derivation","adjudication","cohort","package","operation","control","artifact"),"phase":INT})
add("dependency-graph",obj({"nodes":arr(NODE,1),"edges":arr(EDGE,1),"topological_order":arr(ID,1,True)}))
add("run-manifest",obj({"run_id":ID,"tenant_id":ID,"mode":enum("DESIGN_TEST","SHADOW","PRODUCTION"),"as_of":UTC,
    "journal_offset":INT,"identity_version":S,"registry_release":HASH,"policy_release":HASH,
    "code_revision":HASH,"model_routes":arr(obj({"provider":S,"model":S,"prompt_hash":HASH,"repair_limit":{"type":"integer","minimum":0,"maximum":2}})),
    "budget_ledger_id":ID,"epoch":INT,"previous_epoch_run_id":nullable(ID),"random_seed":INT}))

EVENTKINDS=["FACT_ASSERTED","FACT_RETRACTED","CLAIM_AUTHORITY_CHANGED","CLAIM_COLLISION_RESOLVED", "ENTITY_MERGED","ENTITY_SPLIT",
    "SUBJECT_REBOUND","DERIVATION_EXECUTED","COHORT_COMPUTED","SIGNAL_EVALUATED","ADJUDICATION_RECORDED","PACKAGE_CHANGED", "EXPOSURE_RECORDED", "OUTCOME_RECORDED", "PRIVACY_TOMBSTONE", "COVERAGE_RECORDED","SNAPSHOT_RECORDED"]
add("journal-event",obj({"event_id":ID,"tenant_id":ID,"sequence":{"type":"integer","minimum":1},"schema_version":enum("3.0.0"),
    "kind":enum(*EVENTKINDS),"record_ref":ID,"payload_hash":HASH,"occurred_at":UTC,"recorded_at":UTC,
    "idempotency_key":S,"previous_event_hash":nullable(HASH),"event_hash":HASH,"run_id":ID}))
add("outbox-item",obj({"outbox_id":ID,"tenant_id":ID,"package_id":ID,"recipient_ref":ID,"campaign_ref":ID,"sequence_step":INT,
    "dedup_key":S,"state":enum("PENDING","LEASED","ACCEPTED","FAILED","UNKNOWN_DELIVERY","CANCELLED"),
    "provider_message_id":nullable(S),"attempts":INT,"lease_until":nullable(UTC)}))
add("exposure",obj({"exposure_id":ID,"tenant_id":ID,"subject_id":ID,"recipient_ref":ID,"package_id":ID,"angle_id":ID,
    "service_line":S,"experiment_id":nullable(ID),"arm_id":nullable(ID),"provider_message_id":S,"accepted_at":UTC,
    "delivered_at":nullable(UTC),"bounced_at":nullable(UTC),"eligibility_version":S}))
add("outcome-event",obj({"outcome_id":ID,"tenant_id":ID,"provider":S,"provider_event_id":S,"provider_message_id":S,
    "exposure_id":ID,"kind":enum("DELIVERED","BOUNCED","REPLIED","MEETING","UNSUBSCRIBED"),"occurred_at":UTC,"received_at":UTC,
    "classification":enum("HUMAN_CONFIRMED","PROVIDER_ASSERTED","MODEL_CANDIDATE"),"evidence_ref":ID}))
add("budget-reservation",obj({"reservation_id":ID,"tenant_id":ID,"run_id":ID,"task_id":ID,"ledger_id":ID,
    "reserved_microunits":INT,"actual_microunits":nullable(INT),"state":enum("RESERVED","SETTLED","RELEASED","UNCERTAIN"),"expires_at":UTC}))
add("repair-attempt",obj({"task_id":ID,"attempt":{"type":"integer","minimum":0,"maximum":2},"raw_snapshot_id":ID,
    "parent_attempt_snapshot_id":nullable(ID),"mode":enum("ORIGINAL","DETERMINISTIC_REPAIR","MODEL_REPAIR"),
    "schema_ref":ID,"result":enum("VALID","INVALID","REFUSED","TRUNCATED","FAILED"),"validation_error_codes":arr(S),"budget_reservation_id":ID}))
add("entity",obj({"entity_id":ID,"display_name":S,"class_id":S}))
add("question",obj({"question_id":ID,"text":S}))
add("materializer",obj({"artifact_id":ID,"inputs":arr(ID,1,True),"phase":INT,"contract":S,"implementation":enum("SPECIFIED_NOT_RUNTIME")}))
add("policy",obj({"version":VERSION,"status":enum("PROPOSED_UNCALIBRATED"),"deployment":enum("modular_monolith"),"production_enabled":BOOL,
    "json_profile":enum("RFC8785"),"unknown_never_satisfies":enum(True),"recompute_events":arr(S,1,True),
    "retention_days":obj({"PUBLIC":INT,"BUSINESS_CONFIDENTIAL":INT,"SENSITIVE":INT}),"reply_window_days":INT,
    "minimum_cohort_eligible":INT,"minimum_cohort_coverage":PROB,"minimum_outcome_eligible":INT,"repair_limit":{"type":"integer","minimum":0,"maximum":2},
    "sources":arr(obj({"title":S,"url":{"type":"string","format":"uri"}}),1)}))
add("journal-mutation",{"oneOf":[
    obj({"mutation_id":ID,"kind":enum("FACT_RETRACTED"),"target_fact_ids":arr(ID,1,True),"reason_ref":ID,"effective_at":UTC,"actor_id":ID}),
    obj({"mutation_id":ID,"kind":enum("CLAIM_AUTHORITY_CHANGED"),"registry_ref":ID,"new_authority":AUTH,"reason_ref":ID,"effective_at":UTC,"actor_id":ID}),
    obj({"mutation_id":ID,"kind":enum("CLAIM_COLLISION_RESOLVED"),"claim_key_hash":HASH,"accepted_fact_ids":arr(ID,0,True),"rejected_fact_ids":arr(ID,0,True),"evidence_id":ID,"effective_at":UTC,"actor_id":ID}),
    obj({"mutation_id":ID,"kind":enum("ENTITY_MERGED","ENTITY_SPLIT","SUBJECT_REBOUND"),"from_subject_ids":arr(ID,1,True),"to_subject_ids":arr(ID,1,True),
         "fact_assignments":arr(obj({"fact_id":ID,"new_subject_id":ID})),"identity_version":S,"reason_ref":ID,"effective_at":UTC,"actor_id":ID}),
    obj({"mutation_id":ID,"kind":enum("PRIVACY_TOMBSTONE"),"object_refs":arr(ID,1,True),"key_refs":arr(ID,1,True),"policy_ref":ID,"effective_at":UTC,"actor_id":ID}),
]})
add("delivery-gate",obj({"gate_id":ID,"outbox_id":ID,"package_id":ID,"evaluated_at":UTC,"journal_offset":INT,
    "control_version":S,"registry_release":HASH,"eligible":BOOL,"reason_codes":arr(S),"input_fact_ids":arr(ID,0,True)}))
add("run-plan",obj({"plan_id":ID,"tenant_id":ID,"registry_release":HASH,"policy_release":HASH,"created_at":UTC,
    "budget_ledger_id":ID,"model_routes":arr(obj({"provider":S,"model":S,"prompt_hash":HASH,"repair_limit":{"type":"integer","minimum":0,"maximum":2}})),
    "jobs":arr(obj({"source_id":ID,"scope_id":ID}),1)}))
add("run-completion",obj({"run_id":ID,"input_sequence":INT,"final_sequence":INT,"output_manifest_hash":HASH,
    "completed_at":UTC,"status":enum("COMPLETE","FAILED","ABSTAINED")}))
SCHEMAS['run-manifest']['properties']['plan_id']=ID
SCHEMAS['run-manifest']['required'].append('plan_id')
