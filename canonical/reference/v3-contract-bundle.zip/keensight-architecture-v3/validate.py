#!/usr/bin/env python3
"""Read-only structural + semantic validator for the design release.

No regeneration, network, API credentials, ingestion, or delivery. Mutation tests
can disable byte-integrity checks so they exercise semantic checks independently.
"""
from __future__ import annotations
import argparse,hashlib,json
from collections import Counter
from datetime import datetime
from pathlib import Path
from jsonschema import Draft7Validator, FormatChecker
from catalog import ROOT, REGISTRY_SCHEMAS, INSTANCE_SCHEMAS, read_json, load_authored
from contract_schema import SCHEMAS
from contract_tools.graphs import build_graph, topological_order, leaves
from contract_tools.identity import pointer, slot_for
from contract_tools.rules import evaluate, ALGORITHMS
from contract_tools.fingerprints import match

class Invalid(ValueError): pass

def need(condition,code):
    if not condition: raise Invalid(code)

def stamp(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def digest(b): return 'sha256:'+hashlib.sha256(b).hexdigest()
def validate_schema(value, schema, label):
    errors=list(Draft7Validator(schema,format_checker=FormatChecker()).iter_errors(value))
    need(not errors, f'SCHEMA:{label}:'+('; '.join(e.message for e in errors[:3])))

def indexed(rows, key):
    vals=[x[key] for x in rows];need(len(vals)==len(set(vals)),'DUPLICATE_ID:'+key)
    return dict(zip(vals,rows))

ID_FIELDS={'predicates':'predicate','sources':'source_id','derivations':'flow_id','signal-types':'signal_type','signal-packs':'pack_id','adjudication-packs':'pack_id',
'angle-packs':'angle_pack_id','cohort-definitions':'cohort_id','fingerprints':'fingerprint_id','entities':'entity_id','questions':'question_id','materializers':'artifact_id',
'facts':'fact_id','subjects':'subject_id','scopes':'scope_id','snapshots':'snapshot_id','coverage':'coverage_id','evidence':'evidence_id','signals':'signal_id','adjudications':'adjudication_id','executions':'execution_id','packages':'package_id','runs':'run_id','cohort-snapshots':'cohort_snapshot_id',
'journal-events':'event_id','outbox':'outbox_id','exposures':'exposure_id','outcomes':'outcome_id','budget-reservations':'reservation_id','plans':'plan_id','run-completions':'run_id','repair-attempts':'task_id','journal-mutations':'mutation_id','delivery-gates':'gate_id'}

class Bundle:
    def __init__(self,root=ROOT):
        self.root=Path(root);self.reg={};self.rows={};self.maps={}
    def load(self,verify_release=True):
        actual={p.name for p in (self.root/'schemas').iterdir() if p.is_file()}
        need(actual=={k+'.schema.json' for k in SCHEMAS},'SCHEMA_FILE_SET')
        for name,canonical in SCHEMAS.items():
            actual=read_json(self.root/'schemas'/f'{name}.schema.json')
            Draft7Validator.check_schema(actual)
            need(actual==canonical,'SCHEMA_AUTHORING_DRIFT:'+name)
        expected={k+'.json' for k in REGISTRY_SCHEMAS}|{'dependency-graph.json'}
        need({p.name for p in (self.root/'registry').iterdir() if p.is_file()}==expected,'REGISTRY_FILE_SET')
        for name,schema_name in REGISTRY_SCHEMAS.items():
            val=read_json(self.root/'registry'/f'{name}.json');self.reg[name]=val
            for row in val if isinstance(val,list) else [val]: validate_schema(row,SCHEMAS[schema_name],name)
            if name in ID_FIELDS: self.maps[name]=indexed(val,ID_FIELDS[name])
        for path in sorted((self.root/'instances').rglob('*')):
            if not path.is_file(): continue
            rel=path.relative_to(self.root/'instances')
            need(len(rel.parts)==2 and path.suffix=='.json' and rel.parts[0] in INSTANCE_SCHEMAS,'UNDECLARED_INSTANCE_PATH:'+str(rel))
            kind=rel.parts[0];row=read_json(path);validate_schema(row,SCHEMAS[INSTANCE_SCHEMAS[kind]],str(rel));self.rows.setdefault(kind,[]).append(row)
        for kind in INSTANCE_SCHEMAS:
            self.maps[kind]=indexed(self.rows.get(kind,[]),ID_FIELDS[kind])
        self.graph=read_json(self.root/'registry/dependency-graph.json');validate_schema(self.graph,SCHEMAS['dependency-graph'],'graph')
        if verify_release:
            release=read_json(self.root/'registry-release.json')
            need(release['fixture_only'] is True,'FIXTURE_RELEASE_FLAG')
            for path,h in release['members'].items(): need(digest((self.root/path).read_bytes())==h,'RELEASE_MEMBER_HASH:'+path)
            actual=digest(''.join(f'{k}\0{v}\n' for k,v in sorted(release['members'].items())).encode())
            need(actual==release['release_hash'],'RELEASE_DIGEST')
            from example_catalog import source_hash
            for run in self.rows.get('runs',[]):
                need(run['registry_release']==actual,'RUN_REGISTRY_PIN')
                need(run['policy_release']==digest((self.root/'registry/policy.json').read_bytes()),'RUN_POLICY_PIN')
                need(run['code_revision']==source_hash(self.root),'RUN_CODE_PIN')
        return self

    def linked(self,kind,key):
        need(key in self.maps[kind],f'UNRESOLVED_REFERENCE:{kind}:{key}');return self.maps[kind][key]

    def eligible(self,f,subject,run,seen=None,observed_only=False):
        seen=set() if seen is None else set(seen)
        need(f['fact_id'] not in seen,'PROVENANCE_CYCLE');seen.add(f['fact_id'])
        need(f['tenant_id']==run['tenant_id'],'CROSS_TENANT_FACT')
        if f['subject_id']!=subject:
            # Only a declared cohort join with an explicit frozen snapshot is allowed.
            pred=self.linked('predicates',f['predicate']);need(pred['visibility']=='COHORT_ONLY','CROSS_SUBJECT_FACT')
            ev=self.linked('evidence',f['evidence_id']);ex=self.linked('executions',ev['execution_id'])
            snaps=[self.maps['cohort-snapshots'][x] for x in ex['input_artifact_ids'] if x in self.maps['cohort-snapshots']]
            need(len(snaps)==1,'MISSING_COHORT_JOIN_SNAPSHOT')
            need(subject not in snaps[0]['eligible_subject_ids'],'TARGET_INCLUDED_IN_PEERS')
        need(f['state']=='OBSERVED' if observed_only else f['state']!='UNKNOWN','UNKNOWN_OR_ABSENCE_NOT_ELIGIBLE')
        source=self.linked('sources',f['source']);need(source['authority']=='active','INACTIVE_SOURCE')
        if source['tier'] in ['DERIVED','COHORT']:
            need(self.linked('derivations',source['source_id'])['authority']=='active','INACTIVE_DERIVATION')
        scope=self.linked('scopes',f['scope_id']);need(scope['binding']=='DIRECT','UNBOUND_EVIDENCE')
        age=(stamp(run['as_of'])-stamp(f['observed_at'])).total_seconds()
        need(0<=age<source['ttl_seconds'],'STALE_OR_FUTURE_FACT')
        need(not source['fixture_only'] or run['mode']=='DESIGN_TEST','FIXTURE_SOURCE_IN_REAL_RUN')
        ev=self.linked('evidence',f['evidence_id'])
        for fid in ev['input_fact_ids']: self.eligible(self.linked('facts',fid),subject,run,seen)
        for sid in ev['input_signal_ids']:
            s=self.linked('signals',sid);need(s['status']=='RESOLVED','NONRESOLVED_ANCESTOR_SIGNAL')
            self.signal_inputs(s,seen)
        return True

    def expression(self,expr,facts,signals,subject,run):
        kind=expr['kind']
        if kind in ('all','any'):
            vals=[self.expression(x,facts,signals,subject,run) for x in expr['args']]
            return all(vals) if kind=='all' else any(vals)
        if kind=='signal': return any(s['signal_type']==expr['signal_type'] and s['status']=='RESOLVED' and s['subject_id']==subject for s in signals)
        for f in facts:
            if f['predicate']!=expr['predicate'] or f['state']!=expr['state'] or f['state']=='UNKNOWN': continue
            self.eligible(f,subject,run)
            scope=self.linked('scopes',f['scope_id'])
            if expr['scope_kind']!='any' and scope['kind']!=expr['scope_kind']: continue
            if expr['comparison']=='exists': return True
            try: value=pointer(f['object'],expr['path'])
            except (KeyError,TypeError,IndexError): continue
            expected=expr['value']; op=expr['comparison']
            try:
                ok={'eq':lambda:value==expected,'ne':lambda:value!=expected,'lt':lambda:value<expected,'lte':lambda:value<=expected,
                    'gt':lambda:value>expected,'gte':lambda:value>=expected,'in':lambda:value in expected}[op]()
            except (TypeError,KeyError): ok=False
            if ok: return True
        return False

    def signal_inputs(self,s,seen=None):
        run=self.linked('runs',s['run_id'])
        need(stamp(s['computed_at'])<=stamp(run['as_of']),'FUTURE_SIGNAL')
        fs=[self.linked('facts',x) for x in s['input_fact_ids']]
        ss=[self.linked('signals',x) for x in s['input_signal_ids']]
        for f in fs:
            need(f['tenant_id']==s['tenant_id'],'CROSS_TENANT_SIGNAL_INPUT')
            if s['status']=='RESOLVED': self.eligible(f,s['subject_id'],run,seen)
        for x in ss:
            need(x['signal_id']!=s['signal_id'],'SIGNAL_SELF_CYCLE')
            need(x['subject_id']==s['subject_id'] and x['tenant_id']==s['tenant_id'],'CROSS_SUBJECT_SIGNAL_INPUT')
        if s['status']=='RESOLVED':
            need(fs or ss,'EMPTY_RESOLVED_SIGNAL')
            definition=self.linked('signal-types',s['signal_type'])
            pack=self.linked('signal-packs',s['source_pack']);need(pack['authority']=='active','INACTIVE_SIGNAL_PACK')
            need(self.expression(definition['condition'],fs,ss,s['subject_id'],run),'UNSATISFIED_SIGNAL_CONDITION')
            if definition['requires_coverage']:
                need(any(self.linked('evidence',f['evidence_id'])['coverage_id'] is not None for f in fs),'MISSING_SIGNAL_COVERAGE')

    def check(self):
        reg=self.reg
        # Full bidirectional linker; list multiplicity is checked before indexes.
        for p in reg['predicates']:
            Draft7Validator.check_schema(p['value_schema'])
            need(p['absence_allowed']==('NOT_FOUND' in p['states']),'ABSENCE_STATE_FLAG')
            need(bool(p['identity_paths'])==(p['cardinality']!='singleton'),'CLAIM_IDENTITY_POLICY')
            actual=sorted(d['flow_id'] for d in reg['derivations'] if p['predicate'] in d['outputs'])
            need(sorted(p['derived_by'])==actual,'DERIVED_BY_BACKLINK:'+p['predicate'])
        for s in reg['sources']:
            for p in s['emits']: need(s['tier'] in self.linked('predicates',p)['allowed_tiers'],'SOURCE_TIER_NOT_ALLOWED')
        for d in reg['derivations']:
            need(d['algorithm'] in ALGORITHMS,'UNREGISTERED_ALGORITHM')
            Draft7Validator.check_schema(d['feature_schema']);Draft7Validator.check_schema(d['parameter_schema']);Draft7Validator.check_schema(d['details_schema'])
            validate_schema(d['parameters'],d['parameter_schema'],'parameters:'+d['flow_id'])
            need(set(self.linked('sources',d['flow_id'])['emits'])==set(d['outputs']),'DERIVATION_SOURCE_OUTPUTS')
            need(len({b['name'] for b in d['bindings']})==len(d['bindings']),'DUPLICATE_FEATURE_BINDING')
            for b in d['bindings']: self.linked('predicates' if b['kind']=='predicate' else 'materializers',b['ref'])
            for p in d['outputs']: self.linked('predicates',p)
            for fx in d['fixtures']:
                got=evaluate(d,fx['features']);need(got==fx['expect'],'KERNEL_FIXTURE:'+d['flow_id']+':'+fx['label'])
                validate_schema(got['details'],d['details_schema'],'execution-details')
                for p,val in got['outputs'].items():
                    if got['state']=='OBSERVED': validate_schema(val,self.linked('predicates',p)['value_schema'],'kernel-output:'+p)
            need({x['expect']['state'] for x in d['fixtures']}=={'OBSERVED','UNKNOWN'},'NONVACUOUS_DERIVATION_FIXTURES')
        for a in reg['materializers']:
            for p in a['inputs']: self.linked('predicates',p)
        memberships=Counter(x for p in reg['signal-packs'] for x in p['signal_types'])
        need(set(memberships)==set(self.maps['signal-types']),'PACK_MEMBERSHIP_SET')
        need(all(n==1 for n in memberships.values()),'DUPLICATE_PACK_MEMBERSHIP')
        for s in reg['signal-types']:
            need(s['signal_type'] in self.linked('signal-packs',s['pack'])['signal_types'],'SIGNAL_PACK_MISMATCH')
            negative=False
            for leaf in leaves(s['condition']):
                if leaf['kind']=='fact':
                    p=self.linked('predicates',leaf['predicate']);need(leaf['state'] in p['states'],'UNSUPPORTED_PREDICATE_STATE')
                    need(leaf['state']!='UNKNOWN','UNKNOWN_REQUIREMENT_FORBIDDEN');negative |= leaf['state']=='NOT_FOUND'
                else: self.linked('signal-types',leaf['signal_type'])
            need(not negative or s['requires_coverage'],'MISSING_DECLARED_COVERAGE_FLAG')
        for c in reg['cohort-definitions']:
            for f in c['member_filters']: self.linked('predicates',f['predicate'])
            self.linked('predicates',c['measurement_predicate'])
        expected_graph=build_graph(reg)
        order=topological_order(self.graph['nodes'],self.graph['edges'])
        need(order==self.graph['topological_order'],'INVALID_TOPOLOGICAL_ORDER')
        need(self.graph==expected_graph,'DEPENDENCY_GRAPH_INCOMPLETE_OR_STALE')
        for f in reg['fingerprints']:
            self.linked('predicates',f['emits']);self.linked('entities',f['entity_id'])
            for key,expected in [('must_fire',True),('must_not_fire',False)]:
                for path in f['tests'][key]:
                    p=(self.root/path).resolve();need(p.is_relative_to(self.root.resolve()),'FIXTURE_PATH_ESCAPE')
                    need(p.is_file(),'MISSING_FINGERPRINT_FIXTURE');need(match(f,p.read_text())==expected,'FINGERPRINT_FIXTURE:'+path)
        need(self.maps['questions']=={'booking_crm_handoff':{'question_id':'booking_crm_handoff','text':'How are booked appointments passed into your CRM today?'}},'UNAPPROVED_QUESTION_TEXT')
        for plan in self.rows.get('plans',[]):
            for job in plan['jobs']:
                self.linked('sources',job['source_id']);self.linked('scopes',job['scope_id'])
        for run in self.rows.get('runs',[]):
            plan=self.linked('plans',run['plan_id'])
            need(plan['tenant_id']==run['tenant_id'] and plan['registry_release']==run['registry_release'] and plan['policy_release']==run['policy_release'],'RUN_PLAN_PIN_MISMATCH')
            need(stamp(plan['created_at'])<=stamp(run['as_of']),'RUN_PRECEDES_PLAN')
            need(run['mode']!='PRODUCTION' or reg['policy']['production_enabled'],'PRODUCTION_DISABLED_IN_DESIGN_RELEASE')
            need(run['previous_epoch_run_id']!=run['run_id'],'SELF_REFERENCING_EPOCH')
        for scope in self.rows.get('scopes',[]):
            subject=self.linked('subjects',scope['subject_id']);need(subject['tenant_id']==scope['tenant_id'],'CROSS_TENANT_SCOPE')
        for sn in self.rows.get('snapshots',[]):
            scope=self.linked('scopes',sn['scope_id']);need(sn['resource_uri'] in scope['resources'],'SNAPSHOT_RESOURCE_SCOPE')
            path=(self.root/sn['content_ref']).resolve();need(path.is_relative_to(self.root.resolve()),'CONTENT_PATH_ESCAPE')
            need(path.is_file(),'MISSING_CONTENT_BLOB');body=path.read_bytes()
            need(digest(body)==sn['content_hash'] and len(body)==sn['byte_count'],'CONTENT_INTEGRITY')
        for cov in self.rows.get('coverage',[]):
            scope=self.linked('scopes',cov['scope_id']);src=self.linked('sources',cov['source_id'])
            for p in cov['predicate_ids']: need(p in src['emits'],'COVERAGE_SOURCE_CANNOT_CHECK_PREDICATE')
            for sid in cov['snapshot_ids']:
                snap=self.linked('snapshots',sid);need(snap['scope_id']==scope['scope_id'],'COVERAGE_SCOPE_MISMATCH')
                if cov['status']=='COMPLETE': need(snap['status']=='OK' and not snap['truncated'],'INCOMPLETE_COVERAGE_CAPTURE')
            if cov['status']=='COMPLETE':
                need(set(cov['planned_resources'])==set(cov['completed_resources'])==set(scope['resources']),'INCOMPLETE_RESOURCE_COVERAGE')
                need({self.linked('snapshots',i)['resource_uri'] for i in cov['snapshot_ids']}==set(cov['completed_resources']),'COVERAGE_RESOURCE_WITHOUT_CAPTURE')
        for ev in self.rows.get('evidence',[]):
            need(ev['snapshot_ids'] or ev['input_fact_ids'] or ev['input_signal_ids'] or ev['execution_id'],'EMPTY_PROVENANCE')
            for k,kind in [('snapshot_ids','snapshots'),('input_fact_ids','facts'),('input_signal_ids','signals')]:
                for i in ev[k]: self.linked(kind,i)
            if ev['execution_id']: self.linked('executions',ev['execution_id'])
            if ev['coverage_id']: self.linked('coverage',ev['coverage_id'])
        for fact in self.rows.get('facts',[]):
            p=self.linked('predicates',fact['predicate']);source=self.linked('sources',fact['source'])
            subject=self.linked('subjects',fact['subject_id']);scope=self.linked('scopes',fact['scope_id']);run=self.linked('runs',fact['run_id'])
            need(subject['kind'] in p['subject_kinds'],'PREDICATE_SUBJECT_KIND')
            need(fact['tenant_id']==scope['tenant_id']==subject['tenant_id']==run['tenant_id'],'CROSS_TENANT_FACT')
            need(scope['subject_id']==fact['subject_id'],'FACT_SCOPE_ATTRIBUTION')
            need(fact['predicate'] in source['emits'],'SOURCE_CANNOT_EMIT_PREDICATE')
            need(fact['state'] in p['states'],'PREDICATE_STATE')
            if fact['state']=='OBSERVED':
                validate_schema(fact['object'],p['value_schema'],'predicate-value:'+p['predicate'])
                need(fact['claim_slot']==slot_for(p,fact['object']),'CLAIM_SLOT_MISMATCH')
            elif p['cardinality']=='singleton': need(fact['claim_slot']=='_','SINGLETON_CLAIM_SLOT')
            ev=self.linked('evidence',fact['evidence_id'])
            if source['tier'] in ['DERIVED','COHORT']:
                need(ev['execution_id'],'MISSING_DERIVATION_EXECUTION');ex=self.linked('executions',ev['execution_id'])
                need(fact['fact_id'] in ex['output_fact_ids'] and fact['source']==ex['flow_id'],'EXECUTION_OUTPUT_LINK')
                need(set(ev['input_fact_ids'])==set(ex['input_fact_ids']) and set(ev['input_signal_ids'])==set(ex['input_signal_ids']),'EXECUTION_PROVENANCE_MISMATCH')
            else:
                need(ev['snapshot_ids'],'MISSING_RAW_EVIDENCE')
                for sid in ev['snapshot_ids']: need(self.linked('snapshots',sid)['scope_id']==fact['scope_id'],'RAW_EVIDENCE_SCOPE_MISMATCH')
            if fact['state']=='NOT_FOUND':
                need(ev['coverage_id'],'ABSENCE_WITHOUT_COVERAGE');cov=self.linked('coverage',ev['coverage_id'])
                need(cov['scope_id']==fact['scope_id'] and cov['source_id']==fact['source'] and fact['predicate'] in cov['predicate_ids'],'ABSENCE_COVERAGE_MISMATCH')
                need(cov['status']=='COMPLETE','ABSENCE_INCOMPLETE_COVERAGE')
                need(cov['checked_at']==fact['observed_at'],'ABSENCE_CAPTURE_TIME_MISMATCH')
        # Global provenance DAG independent of semantic dependency graph. Older
        # execution records may not point forward to their own outputs.
        provnodes=[];proedges=[]
        for f in self.rows.get('facts',[]):
            provnodes.append({'node_id':f['fact_id']});ev=self.linked('evidence',f['evidence_id'])
            for parent in ev['input_fact_ids']+ev['input_signal_ids']: proedges.append({'from':parent,'to':f['fact_id'],'kind':'data','epoch_lag':0})
        for s in self.rows.get('signals',[]):
            provnodes.append({'node_id':s['signal_id']})
            for fid in s['input_fact_ids']: self.linked('facts',fid)
            for sid in s['input_signal_ids']: self.linked('signals',sid)
            for parent in s['input_fact_ids']+s['input_signal_ids']: proedges.append({'from':parent,'to':s['signal_id'],'kind':'data','epoch_lag':0})
        topological_order(provnodes,proedges)
        for s in self.rows.get('signals',[]):
            definition=self.linked('signal-types',s['signal_type']);need(s['source_pack']==definition['pack'],'SIGNAL_INSTANCE_WRONG_PACK');self.signal_inputs(s)
        for ex in self.rows.get('executions',[]):
            flow=self.linked('derivations',ex['flow_id']);self.linked('runs',ex['run_id'])
            need(stamp(ex['window']['start'])<=stamp(ex['window']['end']),'INVALID_EXECUTION_WINDOW')
            need(stamp(ex['window']['end'])<=stamp(ex['effective_at']),'FUTURE_EXECUTION_WINDOW')
            validate_schema(ex['details'],flow['details_schema'],'execution-details')
            for fid in ex['input_fact_ids']+ex['output_fact_ids']: self.linked('facts',fid)
            for sid in ex['input_signal_ids']: self.linked('signals',sid)
            ids=sorted(ex['input_fact_ids']+ex['input_signal_ids']+ex['input_artifact_ids'])
            need(ex['input_set_hash']==digest(('\n'.join(ids)+'\n').encode()),'INPUT_SET_DIGEST')
            for fid in ex['output_fact_ids']:
                need(self.linked('facts',fid)['predicate'] in flow['outputs'],'UNDECLARED_EXECUTION_OUTPUT')
            if flow['algorithm']=='automation_maturity':
                inputs=[self.linked('facts',x) for x in ex['input_fact_ids']]
                values=[f['object'] for f in inputs if f['predicate']=='ops.automation.verified' and f['state']=='OBSERVED']
                need(len(values)==1,'MATURITY_VERIFICATION_NOT_UNIQUE')
                res=evaluate(flow,{'verification':values[0]})
                for fid in ex['output_fact_ids']:
                    f=self.linked('facts',fid);need(f['object']==res['outputs'][f['predicate']] and f['state']==res['state'],'EXECUTED_DERIVATION_MISMATCH')
        for adj in self.rows.get('adjudications',[]):
            self.linked('adjudication-packs',adj['source_pack'])
            combined=adj['resolved']+adj['unresolved']+adj['suppressed']
            need(Counter(combined)==Counter(adj['input_signal_ids']),'ADJUDICATION_PARTITION')
            for status in ['resolved','unresolved','suppressed']:
                for sid in adj[status]:
                    s=self.linked('signals',sid);need(s['subject_id']==adj['subject_id'],'ADJUDICATION_SUBJECT');need(s['status']==status.upper(),'ADJUDICATION_STATUS')
        for pkg in self.rows.get('packages',[]): self.package(pkg)
        return {'schemas':len(SCHEMAS),'registry_files':len(REGISTRY_SCHEMAS)+1,'predicates':len(reg['predicates']),'derivations':len(reg['derivations']),'signal_types':len(reg['signal-types']),
                'example_records':sum(map(len,self.rows.values())),'kernel_fixtures':sum(len(d['fixtures']) for d in reg['derivations']),'graph_nodes':len(self.graph['nodes']),'graph_edges':len(self.graph['edges'])}

    def package(self,pkg):
        run=self.linked('runs',pkg['run_id']);need(pkg['mode']==run['mode'],'PACKAGE_RUN_MODE')
        need(pkg['tenant_id']==run['tenant_id'],'PACKAGE_TENANT')
        angle=self.linked('angle-packs',pkg['angle_pack']);adj=self.linked('adjudications',pkg['adjudication_id'])
        need(adj['subject_id']==pkg['subject_id'],'PACKAGE_ADJUDICATION_SUBJECT')
        for name in angle['required_slots']: need(name in pkg['slots'],'MISSING_REQUIRED_SLOT')
        for fid in pkg['slots'].values(): self.eligible(self.linked('facts',fid),pkg['subject_id'],run,observed_only=True)
        maturity=self.linked('facts',pkg['maturity_fact_id']);need(maturity['predicate']=='tag.automation_maturity','WRONG_MATURITY_PREDICATE')
        if pkg['status']!='APPROVED': return
        need(pkg['approved_at'] is not None,'MISSING_APPROVAL_TIME');need(stamp(pkg['approved_at'])<=stamp(run['as_of']),'FUTURE_APPROVAL')
        need(angle['authority']=='active','INACTIVE_ANGLE_PACK');need(self.linked('adjudication-packs',adj['source_pack'])['authority']=='active','INACTIVE_ADJUDICATION_PACK')
        self.eligible(maturity,pkg['subject_id'],run,observed_only=True)
        need(pkg['current_rung']==maturity['object'],'WRONG_CURRENT_RUNG')
        need(int(pkg['offered_rung'][1])==int(pkg['current_rung'][1])+1,'NOT_ONE_RUNG_UP')
        available=[self.linked('signals',x) for x in adj['resolved']]
        need(self.expression(angle['requires'],[],available,pkg['subject_id'],run),'UNSATISFIED_ANGLE_REQUIREMENTS')
        pieces=[]
        for claim in pkg['claims']:
            need(claim['operator'] in angle['claim_operators'],'DISALLOWED_CLAIM_OPERATOR')
            f=self.linked('facts',claim['fact_id']);self.eligible(f,pkg['subject_id'],run,observed_only=True)
            need(self.linked('predicates',f['predicate'])['visibility']=='PUBLIC_MEASUREMENT','INTERNAL_FACT_IN_COPY')
            need(claim['operator']=='observed_vendor','CLAIM_RENDERER_NOT_IMPLEMENTED')
            need(f['predicate']=='vendor.present','CLAIM_PREDICATE_MISMATCH')
            need(self.linked('sources',f['source'])['claim_type']=='EMBEDDED','CLAIM_SOURCE_KIND_MISMATCH')
            ent=self.linked('entities',f['object']['entity_id'])
            need(ent['class_id']==f['object']['class_id'],'ENTITY_CLASS_MISMATCH')
            pieces.append('I noticed a '+ent['display_name']+' embed on your site.')
        need(pkg['question_id'] in angle['question_ids'],'DISALLOWED_QUESTION')
        pieces.append(self.linked('questions',pkg['question_id'])['text'])
        need(pkg['rendered_text']==' '.join(pieces),'UNGROUNDED_OR_MODIFIED_RENDERED_COPY')


def validate_bundle(root=ROOT,verify_release=True): return Bundle(root).load(verify_release).check()

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=ROOT);args=p.parse_args()
    try: print(json.dumps({'status':'PASS',**validate_bundle(args.root)},indent=2))
    except (Invalid,ValueError,KeyError,FileNotFoundError) as exc: raise SystemExit(f'VALIDATION_FAILED: {exc}')
if __name__=='__main__':main()
