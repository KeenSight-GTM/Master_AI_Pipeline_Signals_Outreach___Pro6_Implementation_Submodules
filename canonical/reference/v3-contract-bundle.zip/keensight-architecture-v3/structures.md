# Structures

Exact structural contracts are in `schemas/*.schema.json`; content/rule registrations are in `registry/*.json`.

`python validate.py` loads actual files without regeneration, enables Draft-07 format checks, validates every recognized instance directory, validates all registry record types and nested predicate/feature/parameter schemas, then enforces references, membership, graph integrity, evidence, scope, declared outputs, example readiness and whole-message rendering.

`python generate_structures.py --check` additionally detects drift between authored definitions and generated outputs. Negative semantic tests deliberately disable release-byte verification so that a corrupted business rule is rejected by the relevant semantic check, not only by a checksum mismatch.

A structurally valid object is not necessarily an eligible production observation. Authority, age, subject, evidence and ancestry are evaluated separately. Historical stale/candidate observations may be stored; they cannot feed an approved production decision through a permissive lookup.
