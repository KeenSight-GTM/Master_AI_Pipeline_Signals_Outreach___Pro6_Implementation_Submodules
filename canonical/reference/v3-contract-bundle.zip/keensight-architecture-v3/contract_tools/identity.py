"""Pure claim identity reference. Observation identity is distinct from claim identity."""
import json

def pointer(value,path):
    if path in ('','/'): return value
    for key in path.lstrip('/').split('/'):
        key=key.replace('~1','/').replace('~0','~')
        value=value[int(key)] if isinstance(value,list) else value[key]
    return value

def slot_for(predicate, value):
    if predicate['cardinality']=='singleton': return '_'
    return json.dumps([pointer(value,p) for p in predicate['identity_paths']],separators=(',',':'),ensure_ascii=False)

def claim_key(fact):
    return (fact['tenant_id'],fact['subject_id'],fact['predicate'],fact['claim_slot'],fact['scope_id'])

def observation_key(fact, immutable_input_identity):
    return (*claim_key(fact),fact['source'],immutable_input_identity)

def current_per_source(facts, retracted_ids=()):
    """Preserve observations by source AND claim; UNKNOWN never evicts known evidence.

    Final authority/expiry/conflict adjudication happens after this projection.
    Equal event-time contradictory states remain separate; no artificial tie winner.
    """
    retracted=set(retracted_ids); groups={}
    for f in facts:
        if f['fact_id'] in retracted or f['state']=='UNKNOWN': continue
        k=(*claim_key(f),f['source']); groups.setdefault(k,[]).append(f)
    return {k:sorted([f for f in fs if f['observed_at']==max(x['observed_at'] for x in fs)],key=lambda x:x['fact_id']) for k,fs in groups.items()}
