"""Design-time contracts and reference kernels; no production services."""
