"""Executable design-time numerical kernels, not acquisition/runtime services.

The caller supplies typed, provenance-backed, window-filtered features. Production
materialization of those features is specified in docs/DERIVATIONS.md and is not
implemented by these kernels. All thresholds are proposed, uncalibrated policy.
"""
from __future__ import annotations
from collections import defaultdict
from math import sqrt
from statistics import median, mean, pstdev
from typing import Any

ALGORITHMS = {
    "automation_maturity", "marketing_maturity", "growth_posture", "platform_camp",
    "regulated_vertical", "size_class", "location_model", "business_type",
    "ai_surface_readiness", "stack_complexity", "sales_maturity", "seasonality",
    "icp_fit", "data_quality", "baseline", "percentile", "trend", "outlier",
    "hiring_velocity", "content_velocity", "change_velocity", "tech_rollback", "angle_performance",
}


def wilson(success: int, total: int, z: float = 1.96) -> list[float]:
    if total <= 0 or not 0 <= success <= total:
        raise ValueError("Invalid binomial counts")
    p = success / total
    den = 1 + z*z/total
    c = (p + z*z/(2*total))/den
    half = z*sqrt(p*(1-p)/total + z*z/(4*total*total))/den
    return [max(0.0,c-half), min(1.0,c+half)]


def _direction(a: float, b: float, tolerance: float) -> int:
    if a == b: return 0
    if a == 0: return 1 if b > 0 else -1
    delta = (b-a)/abs(a)
    return 1 if delta > tolerance else (-1 if delta < -tolerance else 0)


def _band(n: float, edges: list[float], labels: list[str]) -> str:
    for edge, label in zip(edges,labels):
        if n < edge: return label
    return labels[-1]


def evaluate(flow: dict[str, Any], f: dict[str, Any]) -> dict[str, Any]:
    from jsonschema import Draft7Validator, FormatChecker
    for value, name in [(f,"feature_schema"),(flow["parameters"],"parameter_schema")]:
        errors = list(Draft7Validator(flow[name], format_checker=FormatChecker()).iter_errors(value))
        if errors: raise ValueError(str(errors[0].message))
    a, p = flow["algorithm"], flow["parameters"]
    if a not in ALGORITHMS: raise ValueError(f"Unknown algorithm: {a}")
    if flow["algorithm_version"]!="2.0.0": raise ValueError("UNREGISTERED_ALGORITHM_VERSION")
    out = flow["outputs"]
    def result(v: Any = None, reason: str | None = None, **metrics: Any) -> dict[str, Any]:
        vals = dict(zip(out,v)) if a == "business_type" and v is not None else {out[0]:v}
        if v is None: vals = {x:None for x in out}
        return {"state":"UNKNOWN" if v is None else "OBSERVED", "outputs":vals,
                "reason":reason if v is None else None,
                "details":{"basis":sorted(f),"metrics":metrics}}
    missing = [b["name"] for b in flow["bindings"] if b["required"] and f.get(b["name"]) is None]
    if missing: return result(reason="MISSING_REQUIRED_FEATURES", missing=missing)

    if a == "automation_maturity":
        v=f["verification"]
        live=any(v[k] for k in ("lowcode_in_use","custom_integrations_live","agents_live"))
        if v["manual_only"] and live: return result(reason="CONTRADICTORY_VERIFICATION")
        if v["agents_live"] and v["custom_integrations_live"]: return result("L3")
        if v["agents_live"]: return result(reason="AGENT_WITHOUT_VERIFIED_INTEGRATION")
        if v["custom_integrations_live"]: return result("L2")
        if v["lowcode_in_use"]: return result("L1")
        return result("L0") if v["manual_only"] else result(reason="NO_LEVEL_PROVEN")
    if a == "marketing_maturity":
        channels=f["channels"]
        known={k:v for k,v in channels.items() if v is not None}
        if len(known)<p["minimum_known"]: return result(reason="THIN_DATA")
        score=100*sum(p["weights"][k]*v for k,v in known.items())/sum(p["weights"][k] for k in known)
        if score==0 and len(known)<len(p["weights"]): return result(reason="NONE_REQUIRES_COMPLETE_COVERAGE")
        return result(_band(score,p["edges"],p["labels"]),score=score)
    if a == "growth_posture":
        ds=[_direction(x[0],x[1],p["relative_tolerance"]) for x in f["pairs"] if x is not None]
        if len(ds)<p["minimum_indicators"]: return result(reason="THIN_HISTORY")
        for d,label in [(1,"GROWING"),(-1,"CONTRACTING"),(0,"STABLE")]:
            if ds.count(d)>=p["minimum_agreeing"]: return result(label,directions=ds)
        return result(reason="DISAGREEMENT",directions=ds)
    if a == "platform_camp":
        v=set(f["providers"]) & {"google","microsoft"}
        if not v: return result(reason="NO_REGISTERED_PROVIDER")
        return result("mixed" if len(v)>1 else ("google_stack" if "google" in v else "microsoft_stack"))
    if a == "regulated_vertical":
        return result(p["crosswalk"].get(f["industry"],"none"))
    if a == "size_class":
        lo,hi=f["employees"]["minimum"],f["employees"]["maximum"]
        if lo<1 or (hi is not None and hi<lo): return result(reason="AMBIGUOUS_EMPLOYEE_INTERVAL")
        if hi is None: return result(p["labels"][-1]) if lo>=p["edges"][-1] else result(reason="AMBIGUOUS_EMPLOYEE_INTERVAL")
        lower=_band(lo,p["edges"],p["labels"]); upper=_band(hi,p["edges"],p["labels"])
        return result(lower) if lower==upper else result(reason="INTERVAL_CROSSES_BAND")
    if a == "location_model":
        locs=f["locations"]
        if f.get("franchise") is True: return result("franchise")
        if len(locs)==1: return result("single_location")
        if not locs or f.get("franchise") is not False: return result(reason="OWNERSHIP_OR_LOCATION_UNKNOWN")
        return result("national" if len({x["region"] for x in locs})>=p["national_regions"] else "regional_chain")
    if a == "business_type": return result([f["business_model"],f["industry"]])
    if a == "ai_surface_readiness":
        ds=f["dimensions"]; known=[x for x in ds if x is not None]; yes=sum(x is True for x in known)
        if len(known)<p["minimum_known"]: return result(reason="THIN_DATA")
        if yes>=p["ready_dimensions"]: return result("ready",dimensions_met=yes)
        if yes>0: return result("partial",dimensions_met=yes)
        if len(known)==p["total_dimensions"]: return result("not_ready",dimensions_met=0)
        return result(reason="UNPROVEN_NEGATIVE_DIMENSIONS")
    if a == "stack_complexity":
        classes=set(f["classes"])
        if len(classes)<p["minimum_classes"]: return result(reason="THIN_STACK_OBSERVATION")
        if f.get("suite_covers_all") is True: return result("unified_suite",class_count=len(classes))
        return result("assembled_stack" if len(classes)>=p["assembled_minimum"] else "light_stack",class_count=len(classes))
    if a == "sales_maturity":
        v=f["verification"]
        if v["manual_only"] and v["connected"]: return result(reason="CONTRADICTORY_VERIFICATION")
        if all(v[k] for k in ("booking","crm","connected")): return result("automated")
        if v["manual_only"]: return result("manual")
        if v["booking"] or v["crm"]: return result("assisted")
        return result(reason="NO_SALES_STATE_PROVEN")
    if a == "seasonality":
        vals=f["months"]
        if len(vals)!=p["minimum_months"] or any(x is None or x<0 for x in vals): return result(reason="INCOMPLETE_MONTHLY_HISTORY")
        years=[vals[:12],vals[12:]]
        med=[median(y) for y in years]
        if any(x==0 for x in med): return result(reason="ZERO_BASELINE")
        peaks=[[i+1 for i,x in enumerate(y) if x>=p["peak_ratio"]*m] for y,m in zip(years,med)]
        recurring=sorted(set(peaks[0])&set(peaks[1]))
        if recurring: return result("seasonal",peak_months=recurring)
        if all(max(y)/m<p["steady_max_ratio"] for y,m in zip(years,med)): return result("steady",peak_months=[])
        return result(reason="IRREGULAR_NOT_RECURRING")
    if a == "icp_fit":
        score=sum(p["scores"][k].get(f[k],0) for k in p["scores"])
        return result(_band(score,p["edges"],p["labels"]),score=score)
    if a == "data_quality":
        v=f["coverage"]
        if not (0<=v["fresh_ratio"]<=1): raise ValueError("Invalid fresh ratio")
        if v["complete"] and v["rendered"] and v["fresh_ratio"]>=p["deep_fresh"]: return result("deep")
        if v["complete"] and v["fresh_ratio"]>=p["standard_fresh"]: return result("standard")
        return result("shallow")
    if a in {"baseline","percentile","outlier"}:
        vals=f["values"]; known=[x for x in vals if x is not None]
        if len(known)<p["minimum_eligible"] or not vals or len(known)/len(vals)<p["minimum_coverage"]:
            return result(reason="INSUFFICIENT_ELIGIBLE_MEMBERS",n_members=len(vals),n_eligible=len(known))
        base={"n_members":len(vals),"n_eligible":len(known),"n_excluded":len(vals)-len(known)}
        if a=="baseline":
            if any(type(x) is not bool for x in known): raise ValueError("Baseline requires Boolean measurements")
            k=sum(known); low,high=wilson(k,len(known),p["wilson_z"])
            return result({**base,"successes":k,"share":k/len(known),"ci_low":low,"ci_high":high})
        target=f["target"]
        if a=="percentile":
            rank=100*(sum(x<target for x in known)+0.5*sum(x==target for x in known))/len(known)
            quality=100-rank if p["direction"]=="lower_is_better" else rank
            return result({**base,"raw_percentile":rank,"quality_percentile":quality})
        sd=pstdev(known)
        if sd==0: return result(reason="ZERO_VARIANCE",**base)
        z=(target-mean(known))/sd
        direction="high" if z>0 else "low" if z<0 else "typical"
        return result({**base,"z":z,"is_outlier":abs(z)>=p["threshold"],"direction":direction})
    if a=="trend":
        shares=f["shares"]; ns=f["eligible_counts"]
        if len(shares)<p["minimum_windows"] or len(ns)!=len(shares) or min(ns)<p["minimum_eligible"]:
            return result(reason="THIN_BALANCED_PANEL")
        n=len(shares); mx=(n-1)/2; my=mean(shares)
        slope=sum((i-mx)*(s-my) for i,s in enumerate(shares))/sum((i-mx)**2 for i in range(n))
        return result({"slope_per_window":slope,"window_count":n,"n_eligible":min(ns),"panel":"balanced"})
    if a=="hiring_velocity":
        prev=set(f["previous_ids"]); cur=set(f["current_ids"])
        if not f["coverage_complete"]: return result(reason="INCOMPLETE_POSTING_COVERAGE")
        return result({"previous_count":len(prev),"current_count":len(cur),"direction":_direction(len(prev),len(cur),p["relative_tolerance"])})
    if a in {"content_velocity","change_velocity"}:
        if not f["comparable"] or f["elapsed_days"]<p["minimum_elapsed_days"]: return result(reason="INCOMPARABLE_CAPTURES")
        if a=="content_velocity":
            rate=len(set(f["changed_urls"]))*p["rate_days"]/f["elapsed_days"]
            return result(_band(rate,p["edges"],p["labels"]),changes_per_30d=rate)
        if f["baseline_pages"]<=0: return result(reason="ZERO_PAGE_BASELINE")
        rate=len(set(f["changed_urls"]))/f["baseline_pages"]*p["rate_days"]/f["elapsed_days"]
        return result(_band(rate,p["edges"],p["labels"]),fraction_per_30d=rate)
    if a=="tech_rollback":
        if not f["comparable"] or not f["coverage_complete"] or not f["template_stable"]: return result(reason="UNPROVEN_COMPARABILITY")
        if f["previously_present"] is not True: return result(reason="NO_PRIOR_PRESENCE")
        return result({"entity_id":f["entity_id"],"public_marker_removed":f["currently_absent"] is True})
    if a=="angle_performance":
        unique={}
        for row in f["exposures"]:
            prior=unique.get(row["exposure_id"])
            if prior is not None and prior!=row: raise ValueError("CONFLICTING_EXPOSURE_ID")
            unique[row["exposure_id"]]=row
        rows=list(unique.values()); groups=defaultdict(list)
        for row in rows: groups[row["unit_id"]].append(row)
        # A measurement unit is assigned once per experiment/window. Repeated sends
        # are retained in the operational ledger but do not multiply denominators.
        units=[]
        for k,rs in sorted(groups.items()):
            if len({x["angle_id"] for x in rs})>1: continue  # contaminated assignment
            first=min(rs,key=lambda x:(x["accepted_at"],x["exposure_id"]))
            units.append({**first, "replied":any(x["replied"] for x in rs),"meeting":any(x["meeting"] for x in rs),
                          "bounced":all(x["bounced"] for x in rs),"unsubscribed":any(x["unsubscribed"] for x in rs)})
        mature=[x for x in units if x["age_days"]>=p["reply_window_days"]]
        eligible=[x for x in mature if not x["bounced"]]
        if len(eligible)<p["minimum_eligible"]: return result(reason="THIN_MATURE_EXPOSURES",n_mature=len(mature),n_eligible=len(eligible))
        r=sum(x["replied"] for x in eligible); meet=sum(x["meeting"] for x in eligible); low,high=wilson(r,len(eligible),p["wilson_z"])
        return result({"n_eligible":len(eligible),"n_accepted":len(groups),"n_mature":len(mature),"n_raw_exposures":len(rows),"n_pending":len(units)-len(mature),"n_bounced":len(mature)-len(eligible),"n_contaminated":len(groups)-len(units),"reply_rate":r/len(eligible),
                       "meeting_rate":meet/len(eligible),"reply_ci_low":low,"reply_ci_high":high,
                       "bounce_rate":sum(x["bounced"] for x in mature)/len(mature),
                       "unsubscribe_rate":sum(x["unsubscribed"] for x in mature)/len(mature),"causal":False})
    raise AssertionError(f"Unhandled registered algorithm: {a}")
