"""Typed same-epoch dependency DAG utilities; identity graph is deliberately separate."""
from __future__ import annotations
from collections import defaultdict
import heapq

CONTROL_EVENTS = ("authority", "binding", "membership", "expiry", "retraction", "release")

def topological_order(nodes, edges):
    ids=[x["node_id"] for x in nodes]
    if len(ids)!=len(set(ids)): raise ValueError("DUPLICATE_GRAPH_NODE")
    known=set(ids); indeg={k:0 for k in ids}; children=defaultdict(set)
    for e in edges:
        u,v=e['from'],e['to']
        if u not in known or v not in known: raise ValueError("UNREGISTERED_GRAPH_ENDPOINT")
        if e['epoch_lag'] not in (0,1): raise ValueError("INVALID_EPOCH_LAG")
        if e['epoch_lag']:
            if e['kind']!='feedback': raise ValueError("ONLY_FEEDBACK_MAY_CROSS_EPOCHS")
            continue
        if u==v: raise ValueError("SELF_CYCLE")
        if v not in children[u]: children[u].add(v); indeg[v]+=1
    queue=[k for k,n in indeg.items() if n==0]; heapq.heapify(queue); order=[]
    while queue:
        u=heapq.heappop(queue); order.append(u)
        for v in sorted(children[u]):
            indeg[v]-=1
            if indeg[v]==0: heapq.heappush(queue,v)
    if len(order)!=len(ids): raise ValueError("DEPENDENCY_CYCLE")
    return order


def leaves(expr):
    if expr['kind'] in ('all','any'):
        for x in expr['args']: yield from leaves(x)
    else: yield expr


def build_graph(reg):
    nodes={}; edges=[]
    def node(k,kind,phase):
        if k in nodes:
            if nodes[k]['kind']!=kind: raise ValueError(f"NODE_KIND_COLLISION:{k}")
            nodes[k]['phase']=max(nodes[k]['phase'],phase)
        else: nodes[k]={'node_id':k,'kind':kind,'phase':phase}
    def edge(u,v,kind='data',lag=0): edges.append({'from':u,'to':v,'kind':kind,'epoch_lag':lag})
    for p in reg['predicates']: node(p['predicate'],'predicate',0)
    for a in reg['materializers']:
        node(a['artifact_id'],'artifact',a['phase'])
        for p in a['inputs']: edge(p,a['artifact_id'])
    for d in reg['derivations']:
        node(d['flow_id'],'derivation',d['phase'])
        for b in d['bindings']: edge(b['ref'],d['flow_id'])
        for p in d['outputs']:
            node(p,'predicate',d['phase']); edge(d['flow_id'],p)
    for s in reg['signal-types']:
        node('signal:'+s['signal_type'],'signal',s['phase'])
        for x in leaves(s['condition']):
            edge(x['predicate'] if x['kind']=='fact' else 'signal:'+x['signal_type'],'signal:'+s['signal_type'])
    node('adjudication.final','adjudication',5)
    for s in reg['signal-types']: edge('signal:'+s['signal_type'],'adjudication.final')
    node('package.compose','package',6); edge('adjudication.final','package.compose'); edge('tag.automation_maturity','package.compose')
    node('operation.send','operation',7); edge('package.compose','operation.send')
    # Journaled exposures/outcomes are exogenous facts at the next frozen read cut.
    # NEVER encode send -> raw outcome -> send as same-epoch recursion.
    node('control.next_epoch','control',0)
    edge('control.next_epoch','package.compose','control')
    edge('angle.performance','control.next_epoch','feedback',1)
    edge('operation.send','control.next_epoch','feedback',1)
    for name in CONTROL_EVENTS:
        k='control.'+name; node(k,'control',0)
        for dest in list(nodes):
            if nodes[dest]['kind'] in ['derivation','signal','artifact','adjudication','package']:
                edge(k,dest,name)
    # Stable de-duplication does not erase parallel edge KINDS.
    edges=[dict(zip(('from','to','kind','epoch_lag'),x)) for x in sorted({(e['from'],e['to'],e['kind'],e['epoch_lag']) for e in edges})]
    ns=sorted(nodes.values(),key=lambda x:x['node_id'])
    order=topological_order(ns,edges)
    for e in edges:
        if e['epoch_lag']==0 and nodes[e['from']]['phase']>nodes[e['to']]['phase']:
            raise ValueError('PHASE_INVERSION:'+e['from']+' -> '+e['to'])
    return {'nodes':ns,'edges':edges,'topological_order':order}


def dirty_closure(graph, changed_nodes):
    ids={n['node_id'] for n in graph['nodes']}
    if not set(changed_nodes)<=ids: raise ValueError('UNKNOWN_DIRTY_NODE')
    children=defaultdict(set)
    for e in graph['edges']:
        if e['epoch_lag']==0: children[e['from']].add(e['to'])
    dirty=set(changed_nodes); stack=list(dirty)
    while stack:
        for nxt in children[stack.pop()]:
            if nxt not in dirty: dirty.add(nxt); stack.append(nxt)
    return [n for n in graph['topological_order'] if n in dirty]
