"""Design-time closed asset detector. Runtime subject attribution is still required.

No raw-HTML regex matching, no prose/link matches. Comments are not parsed as
assets. Untrusted host strings must end on a DNS-label boundary.
"""
from html.parser import HTMLParser
from urllib.parse import urlsplit, urljoin

class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.assets=[]; self.excluded_depth=0
    def handle_starttag(self, tag, attrs):
        if tag in ('footer','article'): self.excluded_depth+=1
        if self.excluded_depth: return
        attrs=dict(attrs)
        value=attrs.get('href' if tag=='link' else 'src')
        if value and tag in ('script','iframe','link'): self.assets.append((tag,value))
    def handle_endtag(self, tag):
        if tag in ('footer','article') and self.excluded_depth: self.excluded_depth-=1

def match(definition,html,base_url='https://example.test/'):
    p=AssetParser(); p.feed(html)
    for op in definition['operators']:
        if op['op']!='asset_host_suffix': raise ValueError('UNSUPPORTED_FINGERPRINT_OPERATOR')
        expected=op['host'].lower().rstrip('.')
        for tag,value in p.assets:
            try:
                parsed=urlsplit(urljoin(base_url,value)); host=(parsed.hostname or '').lower().rstrip('.')
            except ValueError: continue
            if parsed.scheme not in ('http','https') or parsed.username is not None: continue
            if tag in op['tags'] and (host==expected or host.endswith('.'+expected)):
                return True
    return False
