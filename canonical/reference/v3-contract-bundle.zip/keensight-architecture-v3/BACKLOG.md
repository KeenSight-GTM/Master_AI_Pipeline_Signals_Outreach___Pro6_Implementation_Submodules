# Remaining implementation and research work

## Selected design revisions completed in this bundle

The selected issues #1, #3, #4, #5, #6, #7, #8, #10, #14 and #15 are addressed by explicit architectural decisions, revised contracts, executable reference behavior and/or declared runtime acceptance gates. See SYSTEM.md for the issue-to-change matrix. This does not mean the production services specified by those decisions already exist.

## Build work

Follow the five stages in docs/IMPLEMENTATION_PLAN.md. The critical unimplemented pieces are durable journal/replay, runtime source and materializer adapters, full subject/collision/confound handling, persistent invalidation/generation tokens, real provider dispatch/reconciliation, atomic budgets, recorded LLM repair, retention/erasure and source/angle calibration.

## Scope deliberately not certified by this revision

A full real-world fingerprint gold set, complete AI-search multi-probe protocol, production adjudication calibration, end-to-end APIs/LLM/CRM integration, large-scale experiment harness, real entity merges/splits and delivery-safety integration tests remain open. The limited fingerprint helper and tightened safe tie schema do not certify the broader findings #9, #12 or #13 as fully resolved.

The initial copy renderer supports only a grounded vendor observation and the registered neutral question. Attributed-report, scoped-absence and cohort-statistic renderers must have their own typed support and negative fixtures before activation. The type names are reserved, not silently implemented.

Business weights, metric floors, time windows and retention defaults are proposed policy. A separate calibration/approval process must justify production values. Any changes must preserve exact parameter/version pins and update fixed expected fixtures intentionally.

## Not scheduled

No legacy migration, compatibility layer, graph database, distributed ATLAS-scale construction or RAG/ToG/HippoRAG integration is required for the initial implementation. Old code may be reused as components that pass these interfaces and tests.
