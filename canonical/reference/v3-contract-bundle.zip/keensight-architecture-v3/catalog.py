"""Authored sources and generated outputs. No regex extraction from prose.

Edit authoring/*.json for policy/content; contract_schema.py for shapes;
example_catalog.py for synthetic examples. Generated directories are not authored.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
REGISTRY_SCHEMAS={
 'predicates':'predicate','sources':'source','derivations':'derivation-flow',
 'signal-types':'signal-type','signal-packs':'signal-pack','adjudication-packs':'adjudication-pack',
 'angle-packs':'angle-pack','cohort-definitions':'cohort-definition','fingerprints':'fingerprint',
 'entities':'entity','questions':'question','materializers':'materializer','policy':'policy',
}
INSTANCE_SCHEMAS={
 'facts':'fact','subjects':'subject','scopes':'scope','snapshots':'snapshot','coverage':'coverage',
 'evidence':'evidence','signals':'signal','adjudications':'adjudication-record','executions':'execution',
 'packages':'outreach-package','runs':'run-manifest','cohort-snapshots':'cohort-snapshot',
 'journal-events':'journal-event','outbox':'outbox-item','exposures':'exposure','outcomes':'outcome-event',
 'plans':'run-plan','run-completions':'run-completion','budget-reservations':'budget-reservation','repair-attempts':'repair-attempt','journal-mutations':'journal-mutation','delivery-gates':'delivery-gate',
}

def unique_object(pairs):
    d={}
    for k,v in pairs:
        if k in d: raise ValueError('DUPLICATE_JSON_KEY:'+k)
        d[k]=v
    return d

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=unique_object,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('NONFINITE_JSON:'+x)))

def load_authored(root=ROOT):
    expected={f'{n}.json' for n in REGISTRY_SCHEMAS}
    actual={p.name for p in (root/'authoring').iterdir() if p.is_file()}
    if actual!=expected: raise ValueError(f'AUTHORING_FILE_SET: missing={expected-actual}, extra={actual-expected}')
    return {n:read_json(root/'authoring'/f'{n}.json') for n in REGISTRY_SCHEMAS}
