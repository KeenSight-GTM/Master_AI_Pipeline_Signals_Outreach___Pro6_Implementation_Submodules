"""Synthetic contract-level fixtures. These are not calibration or runtime outputs."""
import hashlib,json
from contract_tools.identity import slot_for
from contract_tools.rules import evaluate

def digest(b): return 'sha256:'+hashlib.sha256(b).hexdigest()

def source_hash(root):
    paths=sorted(list(root.glob('*.py'))+list((root/'contract_tools').glob('*.py')))
    return digest(''.join(p.relative_to(root).as_posix()+'\0'+digest(p.read_bytes())+'\n' for p in paths).encode())

def build_examples(reg,release_hash,policy_hash,root):
    rows={}
    def add(kind,record): rows.setdefault(kind,[]).append(record);return record
    tenant='tenant.fixture'; run='run.fixture'; as_of='2026-09-14T12:00:00Z'; observed='2026-09-13T12:00:00Z'
    for name in ['acme','northside']:
        add('subjects',dict(subject_id='org.'+name,tenant_id=tenant,kind='ORG',canonical_subject_id='org.'+name))
        add('scopes',dict(scope_id='scope.'+name,subject_id='org.'+name,tenant_id=tenant,kind='site',resources=['https://'+name+'.example/'],capture_mode='raw_html',binding='DIRECT',binding_version='binding.fixture.v1'))
    add('scopes',dict(scope_id='scope.ops',subject_id='org.acme',tenant_id=tenant,kind='authorized_system',resources=['human:verification.fixture'],capture_mode='human_record',binding='DIRECT',binding_version='binding.fixture.v1'))
    fixtures=[('snap.calendly','scope.acme','fixtures/calendly-positive.html','text/html'),
              ('snap.make','scope.acme','fixtures/make.html','text/html'),
              ('snap.ops','scope.ops','fixtures/ops-verification.json','application/json'),
              ('snap.northside','scope.northside','fixtures/no-booking.html','text/html')]
    for sid,scope,path,mime in fixtures:
        b=(root/path).read_bytes()
        add('snapshots',dict(snapshot_id=sid,scope_id=scope,content_hash=digest(b),content_ref=path,resource_uri=('human:verification.fixture' if scope=='scope.ops' else 'https://northside.example/' if scope=='scope.northside' else 'https://acme.example/'),media_type=mime,byte_count=len(b),captured_at=observed,status='OK',truncated=False,retention_policy='retention.fixture.v1',classification='PUBLIC' if mime=='text/html' else 'BUSINESS_CONFIDENTIAL'))
    pmap={p['predicate']:p for p in reg['predicates']}
    def fact(fid,pred,value,source,snap,scope='scope.acme',subject='org.acme',state='OBSERVED',coverage=None,inputs=None,execution=None,slot=None):
        eid='evidence.'+fid
        add('evidence',dict(evidence_id=eid,snapshot_ids=[snap] if snap else [],input_fact_ids=inputs or [],input_signal_ids=[],execution_id=execution,coverage_id=coverage,
                           locator='fixture:'+fid,independence_groups=['fixture.'+pred] if not inputs else ['fixture.ops.automation.verified']))
        return add('facts',dict(fact_id=fid,tenant_id=tenant,subject_id=subject,predicate=pred,claim_slot=slot or (slot_for(pmap[pred],value) if value is not None else '_'),scope_id=scope,object=value,state=state,source=source,observed_at=observed,evidence_id=eid,run_id=run))
    fact('fact.calendly','vendor.present',{'entity_id':'calendly','class_id':'scheduler'},'source.vendor.present@3.0.0','snap.calendly')
    fact('fact.make','automation.platform.present',{'entity_id':'make','class_id':'automation'},'source.automation.platform.present@3.0.0','snap.make')
    v={'manual_only':False,'lowcode_in_use':True,'custom_integrations_live':False,'agents_live':False}
    fact('fact.verification','ops.automation.verified',v,'source.ops.automation.verified@3.0.0','snap.ops',scope='scope.ops')
    flow=next(f for f in reg['derivations'] if f['algorithm']=='automation_maturity'); res=evaluate(flow,{'verification':v})
    fact('fact.maturity','tag.automation_maturity',res['outputs']['tag.automation_maturity'],flow['flow_id'],None,scope='scope.ops',inputs=['fact.verification'],execution='exec.maturity')
    ih=digest(('fact.verification\n').encode())
    add('executions',dict(execution_id='exec.maturity',flow_id=flow['flow_id'],run_id=run,subject_id='org.acme',scope_id='scope.ops',input_fact_ids=['fact.verification'],input_signal_ids=[],input_artifact_ids=[],input_set_hash=ih,output_fact_ids=['fact.maturity'],effective_at=observed,
        window={'start':observed,'end':observed},status='OBSERVED',reason=None,details=res['details']))
    add('coverage',dict(coverage_id='coverage.northside',scope_id='scope.northside',source_id='source.booking.present@3.0.0',predicate_ids=['booking.present'],planned_resources=['https://northside.example/'],completed_resources=['https://northside.example/'],snapshot_ids=['snap.northside'],status='COMPLETE',checked_at=observed,detector_release=release_hash))
    fact('fact.no-booking','booking.present',None,'source.booking.present@3.0.0','snap.northside',scope='scope.northside',subject='org.northside',state='NOT_FOUND',coverage='coverage.northside',slot='class:scheduler')
    add('signals',dict(signal_id='signal.lowcode',tenant_id=tenant,subject_id='org.acme',signal_type='LOWCODE_ACTIVE',status='RESOLVED',reason=None,input_fact_ids=['fact.make'],input_signal_ids=[],source_pack='pack.workflow-gaps@3.0.0',computed_at=observed,run_id=run))
    add('signals',dict(signal_id='signal.disconnection-unresolved',tenant_id=tenant,subject_id='org.acme',signal_type='BOOKING_CRM_DISCONNECT',status='UNRESOLVED',reason='THIN_DATA',input_fact_ids=['fact.calendly'],input_signal_ids=[],source_pack='pack.workflow-gaps@3.0.0',computed_at=observed,run_id=run))
    add('adjudications',dict(adjudication_id='adj.acme',subject_id='org.acme',source_pack='adj.core@3.0.0',input_signal_ids=['signal.lowcode','signal.disconnection-unresolved'],resolved=['signal.lowcode'],unresolved=['signal.disconnection-unresolved'],suppressed=[],computed_at=observed))
    add('packages',dict(package_id='package.fixture',revision=1,supersedes_package_id=None,tenant_id=tenant,subject_id='org.acme',angle_pack='angle.booking-assessment@3.0.0',adjudication_id='adj.acme',maturity_fact_id='fact.maturity',current_rung='L1',offered_rung='L2',claims=[{'operator':'observed_vendor','fact_id':'fact.calendly'}],question_id='booking_crm_handoff',rendered_text='I noticed a Calendly embed on your site. How are booked appointments passed into your CRM today?',slots={},status='APPROVED',run_id=run,approved_at=observed,mode='DESIGN_TEST'))
    add('plans',dict(plan_id='plan.fixture',tenant_id=tenant,registry_release=release_hash,policy_release=policy_hash,created_at='2026-09-13T00:00:00Z',budget_ledger_id='budget.fixture',model_routes=[],jobs=[{'source_id':'source.vendor.present@3.0.0','scope_id':'scope.acme'}]))
    add('runs',dict(run_id=run,plan_id='plan.fixture',tenant_id=tenant,mode='DESIGN_TEST',as_of=as_of,journal_offset=100,identity_version='binding.fixture.v1',registry_release=release_hash,policy_release=policy_hash,code_revision=source_hash(root),model_routes=[],budget_ledger_id='budget.fixture',epoch=1,previous_epoch_run_id=None,random_seed=0))
    return rows
