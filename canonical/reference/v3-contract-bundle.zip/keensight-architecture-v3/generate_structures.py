#!/usr/bin/env python3
"""Generate artifacts only. Validation is a separate, read-only command."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from catalog import ROOT,load_authored,REGISTRY_SCHEMAS
from contract_schema import SCHEMAS
from contract_tools.graphs import build_graph
from example_catalog import build_examples,digest

def encode(obj): return (json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')

def expected_files(root=ROOT):
    reg=load_authored(root); generated={}
    for name,sch in sorted(SCHEMAS.items()): generated[f'schemas/{name}.schema.json']=encode(sch)
    for name,value in sorted(reg.items()): generated[f'registry/{name}.json']=encode(value)
    generated['registry/dependency-graph.json']=encode(build_graph(reg))
    # Release digest covers the exact immutable bytes; not a custom JCS implementation.
    members={k:digest(v) for k,v in generated.items()}
    for f in sorted((root/'fixtures').iterdir()):
        if f.is_file(): members[f.relative_to(root).as_posix()]=digest(f.read_bytes())
    release=digest(''.join(f'{k}\0{v}\n' for k,v in sorted(members.items())).encode())
    generated['registry-release.json']=encode({'release_hash':release,'algorithm':'sha256-path-nul-filehash-lf-v1','members':members,'fixture_only':True})
    examples=build_examples(reg,release,digest(generated['registry/policy.json']),root)
    for kind,records in examples.items():
        for i,record in enumerate(records,1): generated[f'instances/{kind}/{i:03}.json']=encode(record)
    return generated

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args(); files=expected_files(args.root)
    if args.check:
        missing=[p for p,b in files.items() if not (args.root/p).exists() or (args.root/p).read_bytes()!=b]
        actual={f.relative_to(args.root).as_posix() for d in ('schemas','registry','instances') for f in (args.root/d).rglob('*') if f.is_file()}
        extra=actual-{p for p in files if p.startswith(('schemas/','registry/','instances/'))}
        if missing or extra: raise SystemExit(f'GENERATED_DRIFT: changed/missing={missing}; extra={sorted(extra)}')
        print(f'PASS: {len(files)} generated JSON files match authoring exactly')
    else:
        for p,b in files.items():
            dest=args.root/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        print(f'Generated {len(files)} JSON files. Run python validate.py separately.')
if __name__=='__main__': main()
