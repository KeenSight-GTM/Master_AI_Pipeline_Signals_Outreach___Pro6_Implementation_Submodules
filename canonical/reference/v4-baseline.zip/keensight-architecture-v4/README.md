# KeenSight architecture v4 — broad facts and research context

September 14, 2026 · **Combination C: account facts + enrichment + product/industry research context.**

This is an updated contract, catalog, documentation and reference-validation bundle. It is not the production scanner, persistent application, licensed data integration, or sending service.

**Breadth is mandatory at the fact layer. Activation is selective at the capture, execution and commercial layers.** A fact does not need an enabled signal or campaign to be admitted. Unknown concepts are quarantined rather than inserted under an untyped production predicate.

| Delivered item | Inventory |
|---|---:|
| Predicate definitions | 197, preserving all 87 v3 identifiers and adding 110 |
| Metric definitions | 89 |
| Exported Draft-07 contract/value-object schemas | 58 |
| User domain coverage records | 11 |
| Registry collections | 13 |
| Synthetic example records | 144, including 27 facts and three preview packages |
| UML/dataflow views | 14, with editable Mermaid and rendered SVG |
| Proposed application interfaces | 19 |

The 197 predicates are a starting catalog, not a maximum. The user's aggregate 424 catalog entries were not supplied as individual rows; this bundle maps the eleven areas and their representative concepts rather than claiming a one-to-one audit of those 424 entries. It does not contain 2,500 executable signatures. One narrowly scoped fingerprint and six fixtures exercise the reference path.

## Start here

- [Main architecture](SYSTEM.md)
- [Complete rendered diagram book](KeenSight_v4_Diagrams.html)
- [All editable UML/dataflow diagrams](docs/DIAGRAMS.md)
- [Every exported class and field](docs/CLASS_REFERENCE.md)
- [Contracts and invariant semantics](docs/CONTRACTS.md)
- [Eleven-domain mapping](docs/COVERAGE.md), [full predicate catalog](docs/CATALOG.md), [all metrics](docs/METRICS.md)
- [Research-context contract](docs/RESEARCH_CONTEXT.md)
- [Persistence and batch execution](docs/PERSISTENCE_BATCH.md)
- [Source governance](docs/SOURCE_GOVERNANCE.md)
- [Implementation boundary and build plan](docs/IMPLEMENTATION_SCOPE.md)
- [Measured validation report](VALIDATION.md)

## Reproduce the checks

Use Python 3.11+; the exact verification environment is recorded in VALIDATION.md. Install in a virtual environment:

```bash
python -m pip install -r requirements.txt
python generate.py --check
python validate.py
python -m pytest -q
```

To author a revision, change `keensight_contracts/shapes.py`, `catalog.py`, or `bootstrap.py`; then run `python generate.py`, `python validate.py` and the tests. `generate.py --check` never rewrites files. The generator does not replace the validator.

`python build_diagrams.py` additionally requires a local Graphviz `dot` executable. Mermaid source files are provided; Graphviz and a local sequence renderer produced the SVGs, not the Mermaid CLI.

## Deliberate boundaries

All source approvals and data in the runnable fixture are synthetic; `production_enabled` and sending are disabled. Real provider blueprints require implementation and a source-specific access/retention review before use. The class/interface diagrams describe proposed code organization, not 19 deployed services.

The original v3 archive is preserved byte-for-byte under `reference/`, including its original tests and reference derivations. The 18 old signal definitions and 23 numerical kernels remain reference assets, not automatically enabled v4 implementations. The v4 wire envelope is not a drop-in v3 replacement, and no old repository migration was performed.
