# Normative contract notes

Version 4.0.0. JSON Schemas plus the semantic validator are normative for the delivered design-test profile. The following rules are binding on the proposed runtime; the implementation-scope document distinguishes actual checks from future repository/adapter work.

## Validation order

Read JSON with duplicate-key/nonfinite rejection. Validate the envelope. Resolve predicate and other registrations. Dispatch `Fact.target` and OBSERVED `Fact.object` through the predicate schemas. Dispatch metric dimensions and values through MetricDefinition. Validate subject/source/evidence/period references, epistemic permissions and chronological relationships. Separately check current-use eligibility for the requested purpose. Validate the entire rendered clause and package.

CandidateRecord.proposed_value is the only deliberately quarantined arbitrary candidate payload. It is not interchangeable with a Fact and has no commercial authority. Registries themselves may contain JSON Schema objects and function-parameter schemas; these are meta-contracts, not permissive live values.

## Contract groups

| Group | Classes | Purpose |
|---|---|---|
| Identity | Subject, Scope, SubjectBinding, PredicateDefinition, Fact, ClaimResolution, CandidateRecord, ChangeRecord | Identify observations, what they concern, their exact claim target and corrections. |
| Evidence/rights | SourceDefinition, ProviderBlueprint, DataAccessPolicy, Artifact, EvidenceLocator, EvidenceSet, CoverageRecord | Preserve evidence and source restrictions without treating an API name as proof. |
| Domain payloads | TechnologyValue/ReportValue, JobPostingValue, SalaryValue, AttributedStatementValue, SurfaceObservationValue, HypothesisValue, QuotedTextResult | Reusable typed shape families; individual predicate schemas remain authoritative. |
| Research/metrics | MetricDefinition, MeasurementValue, TaxonomyTerm, ResearchSample, ResearchPriorValue, ReviewRecordValue, DiscussionRecordValue, ThemeClassificationValue | Separate records, classifications, samples and calculations. |
| Registry/phone/outcomes | RegistryRecordValue, CallEventValue, EconomicHypothesisValue, Exposure, OutcomeEvent | Issuer meaning, authorized observations, explicit assumptions and future exposure identity. |
| Evaluation | BatchRun, CapabilityProfile, FunctionDefinition, ExecutionRecord, ModelCall, RepairAttempt, FingerprintDefinition, CalibrationRecord, CoverageFamilyPlan | Pin definitions/inputs and distinguish enabled code from design-only content. |
| Commercial | ContextJoinRule, ContextAssessment, SignalDefinition, SignalEvaluation, TemplateDefinition, GroundedClause, OutreachPackage | Limit research joins, signal readiness and outward assertions. |
| Shared objects | TimeWindow, ExternalIdentifier, ConfidenceAssessment, ObjectReferenceRule, CoverageCheck, FactRequirement | Common closed embedded values. |

## Fact state and nature

OBSERVED requires a nonnull predicate-specific object and no failure reason. NOT_FOUND requires null object, a declared absence-compatible predicate and a valid coverage record matching target/source/scope. UNKNOWN requires null object and a reason such as FETCH_FAILED, POLICY_BLOCKED, AMBIGUOUS_ATTRIBUTION or INSUFFICIENT_EVIDENCE. A failed adapter implementation is a configuration failure, not a company fact.

Nature records epistemic meaning; source acquisition and producing processor are separate. An API can supply an estimate, direct authorized measurement or registry record. An LLM can extract an exact attributed statement or produce an inference. Its confidence does not change source authority or evidence kind.

## Identity

Claim identity uses tenant, subject, predicate, nature, scope, target and reporting window. Source IDs remain on observations; multiple sources do not create artificial independent evidence. The value is not generically part of identity. Predicate targets name identities such as product, posting ID, license issuer/ID, metric dimensions or statement ID. API estimates have provider/method identity in their measurement target. Source-specific histories coexist.

ClaimResolution is an explicitly evaluated projection; it is not the primary store. UNKNOWN does not erase usable known values. Only a valid, eligible explicit successor removes a prior observation from the reference resolution. Conflicts retain the original observations. No uncalibrated probability multiplication is prescribed.

## Raw and derived provenance

Raw evidence must resolve to existing, same-tenant retained bytes and exact locators. A source recipe alone is not an evidence path. Root artifact hashes and byte sizes are verified. Subject binding references the evidence and actual scope. Comment/blog/footer markers cannot acquire owner attribution by merely matching a vendor name.

Derived facts point to an ExecutionRecord and its exact input facts; matching backlinks are required. Input subject changes are forbidden except through the dedicated ContextAssessment path, which is not a company Fact. Parent facts must have been recorded before execution starts. Raw observations keep capture time; recomputation does not refresh the underlying evidence age. Derived freshness cannot exceed the earliest input expiry. Candidate/retired/expired/retracted ancestry cannot support current copy.

The input_set_hash commits sorted immutable record references. The production repository must enforce immutable record IDs and reject same-ID/different-content writes; the release file hashes commit the fixture's full records and blobs. This reference digest uses canonical Python JSON, not a claim of RFC-8785 compatibility or universal cross-language numeric hashing.

## Time

`as_of` is logical evaluation time, not a wall-clock execution deadline. Source observations must not be later than it. Execution start/finish are ordered wall-clock times; computation can finish later. Approval must follow the recording of all outward-claim support. `effective_at` preserves publication/effective/event time when available. A measurement window is `[start,end)`; timezone and source methodology remain explicit.

No implicit conversion between financial AUM, revenue, salary, traffic or review scales is permitted. Salary is a distinct range with currency and pay period; omitted salary is not a zero. Rating scales are retained. Rates requiring a denominator reject zero denominators and inconsistent arithmetic. Provider-calculated values remain provider values when the underlying denominator is unavailable, according to the metric's contract.

## Absence

Coverage lists the declared resources and checked results. COMPLETE requires the same resource set, successful nontruncated captures, matching source and scope, and matching predicate targets. Different capture modes remain different scopes. Public non-detection cannot be converted into verified absence of private operations.

## Research and inference

Review and forum statements retain attribution; classifier output retains INFERENCE nature and raw parent facts. ResearchPriorValue is a descriptive calculation within a ResearchSample. Counts deduplicate origin records, not people. Parent artifacts and transformed copies preserve the original identity/independence group. A small or biased sample cannot establish population prevalence or causal pain; consumer-specific support thresholds must be versioned and calibrated separately.

Product/industry context has its own subject, an explicit allowed link, a one-hop limit, INTERNAL_RESEARCH purpose and company_claim_allowed=false. Outward copy must use eligible same-account facts. Related product evidence can guide an investigation without making a factual claim about the account.

## Copy and maturity

Each reviewed template declares its predicate, allowed natures, renderer and vetted neutral question. Clauses retain exact fact references and evidence roles. The approved text must exactly equal the reference rendering. This validates the supported wording of the supplied narrow templates, not arbitrary natural-language truth.

The observation/question mode has no maturity prerequisite. MATURITY_OFFER is reserved but currently rejected by the reference renderer. Unreviewed generated prose stays draft-only. Field escaping/sanitization and source-specific attribution presentation remain required in the eventual output channel adapter.

## Rights and privacy

Source policies include tenant-specific permission scope and gate capture, retention, derivation, model processing, internal use, outreach and export separately. Synthetic policy approvals do not confer any real license. Expired or deleted evidence cannot support a new approval. Derivatives inherit relevant parent restrictions; a source hash is not a substitute for retained inspectable support. Do not build personal health or forum-user profiles from the supported research families. Authorized phone samples use aggregate/non-sensitive metadata by default; audio recording/transcription requires separate explicit authorization and an implemented restricted-data path.

## Extensibility

Adding a product usually adds a Subject and fingerprint definitions, not a new vendor-specific Fact subclass. Adding a new metric adds a MetricDefinition and tests. Adding a genuinely new fact concept requires a predicate value/target schema, identity, allowed subjects/natures/processors, source mapping, reference rules, state behavior and fixtures. No new concept gets production status simply because it appeared in model JSON.

All 87 v3 predicate identifiers remain for continuity, but the v4 envelope and some field/identity semantics changed. V3 payloads must not be relabeled 4.0.0 without validation. No automatic migration is supplied.
