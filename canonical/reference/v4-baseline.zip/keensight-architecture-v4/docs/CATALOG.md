# Full predicate catalog — 197 definitions

Generated review view. `registry/predicates.json` is the generated machine contract; authoring lives in `keensight_contracts/catalog.py`. All 87 v3 identifiers are retained; this is not v3 wire compatibility.

| Predicate | Family | Subjects | Nature | Period mode | Copy policy | Origin |
|---|---|---|---|---|---|---|
| `account.industry_membership` | identity | ORG, LOCATION | FIRST_PARTY_STATEMENT, REGISTRY_RECORD | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `account.stage` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `acquisition.coverage` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `ads.activity` | legacy.growth | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `ads.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `advertisement.record` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `angle.performance` | legacy.derived | ANGLE | DERIVED_MEASUREMENT | POINT | CONTEXT_ONLY | V3_RETAINED |
| `api.public.present` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `app.listing` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `app.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `app.mobile.present` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `automation.platform.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `automation_opportunity.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `backlink.record` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `booking.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `business.profile_attribute` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `business_model.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `careers.ats` | hiring | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `careers.page` | hiring | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `cert.new_subdomain` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `change.page.delta` | legacy.change | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `change.template.stable` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `change.velocity` | legacy.change | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | INTERNAL_ONLY | V3_RETAINED |
| `chat.widget.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `cohort.baseline` | legacy.cohort | COHORT | DERIVED_MEASUREMENT | POINT | CONTEXT_ONLY | V3_RETAINED |
| `cohort.outlier` | legacy.cohort | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | CONTEXT_ONLY | V3_RETAINED |
| `cohort.percentile` | legacy.cohort | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | CONTEXT_ONLY | V3_RETAINED |
| `cohort.trend` | legacy.cohort | COHORT | DERIVED_MEASUREMENT | POINT | CONTEXT_ONLY | V3_RETAINED |
| `company.age_band` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `company.business_model` | legacy.operational | ORG, LOCATION, BRAND | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V3_RETAINED |
| `company.geo` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `company.locations` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `company.self_claim` | legacy.identity | ORG, LOCATION, BRAND | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V3_REVISED |
| `competitor.presence` | legacy.reputation | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `content.page_inventory` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `content.type.present` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `content.velocity_band` | legacy.content_seo | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | INTERNAL_ONLY | V3_RETAINED |
| `crm.note` | legacy.operational | ORG, LOCATION, BRAND | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V3_REVISED |
| `crm.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `customer_type.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `discussion.record` | community | SOFTWARE_PRODUCT, INDUSTRY | THIRD_PARTY_REPORT | EVENT | CONTEXT_ONLY | V4_ADDED |
| `discussion.statement` | community | SOFTWARE_PRODUCT, INDUSTRY | THIRD_PARTY_REPORT | EVENT | CONTEXT_ONLY | V4_ADDED |
| `discussion.theme_classification` | community | SOFTWARE_PRODUCT, INDUSTRY | INFERENCE | POINT | CONTEXT_ONLY | V4_ADDED |
| `dns.cname.service` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `dns.dmarc.policy` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `dns.mx.provider` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `dns.spf.includes` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `dns.txt.verification` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `document.surface` | website_analysis | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `document_complexity.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `esp.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `firmo.employee_band` | legacy.firmographics | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `firmo.funding` | legacy.firmographics | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `firmo.ownership` | legacy.firmographics | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `firmo.revenue_band` | legacy.firmographics | ORG, LOCATION, BRAND | PROVIDER_ESTIMATE, FIRST_PARTY_STATEMENT | POINT | ESTIMATE_ATTRIBUTED | V3_RETAINED |
| `form.surface` | website_analysis | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `handoff_risk.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `headcount.history` | legacy.growth | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `hiring.change_event` | hiring | ORG, LOCATION | DERIVED_MEASUREMENT | EVENT | INTERNAL_ONLY | V4_ADDED |
| `hiring.measurement` | measurement | LOCATION, ORG, WEBSITE | DERIVED_MEASUREMENT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `hiring.role` | legacy.growth | ORG, LOCATION, BRAND | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V3_RETAINED |
| `hiring.velocity` | legacy.growth | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | INTERNAL_ONLY | V3_RETAINED |
| `identity.binding_evidence` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `industry.pain_prior` | research | INDUSTRY | DERIVED_MEASUREMENT | PERIOD | CONTEXT_ONLY | V4_ADDED |
| `industry.subvertical` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `industry.vertical` | legacy.identity | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `integration.connection.verified` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `integration.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `integration.public_marker` | vertical_software | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `job.crm_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.department` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.document_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.follow_up_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.handoff_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.location` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.manual_process_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.posting` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.salary` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.skill_requirement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.spreadsheet_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.status` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.tool_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.work_arrangement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `job.workflow_statement` | hiring | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `knowledge_complexity.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `lead_channel.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `location.data.consistency` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `news.events` | legacy.growth | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `ops.automation.verified` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `ops.sales.verified` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `outreach.exposure` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `outreach.outcome` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `payment.processor.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `person.contact` | legacy.firmographics | ORG, LOCATION, BRAND, PERSON | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_REVISED |
| `phone.call_event` | phone | ORG, LOCATION | DIRECT_OBSERVATION | EVENT | INTERNAL_ONLY | V4_ADDED |
| `phone.cta` | phone | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `phone.economics_hypothesis` | phone | ORG, LOCATION | INFERENCE | PERIOD | INTERNAL_ONLY | V4_ADDED |
| `phone.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, THIRD_PARTY_REPORT | PERIOD | INTERNAL_ONLY | V4_ADDED |
| `phone.recording_verified` | phone | ORG, LOCATION | FIRST_PARTY_STATEMENT, DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V4_ADDED |
| `phone.routing_observed` | phone | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `phone.routing_verified` | phone | ORG, LOCATION | FIRST_PARTY_STATEMENT, DIRECT_OBSERVATION | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `portal.observed` | vertical_software | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `product.capability` | product | SOFTWARE_PRODUCT | FIRST_PARTY_STATEMENT, THIRD_PARTY_REPORT | POINT | CONTEXT_ONLY | V4_ADDED |
| `product.category` | product | SOFTWARE_PRODUCT | FIRST_PARTY_STATEMENT, THIRD_PARTY_REPORT | POINT | CONTEXT_ONLY | V4_ADDED |
| `product.integration_support` | product | SOFTWARE_PRODUCT | FIRST_PARTY_STATEMENT, THIRD_PARTY_REPORT | POINT | CONTEXT_ONLY | V4_ADDED |
| `product.pain_prior` | research | SOFTWARE_PRODUCT | DERIVED_MEASUREMENT | PERIOD | CONTEXT_ONLY | V4_ADDED |
| `product.vertical` | product | SOFTWARE_PRODUCT | FIRST_PARTY_STATEMENT, THIRD_PARTY_REPORT | POINT | CONTEXT_ONLY | V4_ADDED |
| `registry.affiliation` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `registry.filing` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `registry.license` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `registry.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, REGISTRY_RECORD | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `registry.permit` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `registry.registration` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `registry.specialty` | public_registry | ORG, LOCATION, PERSON | REGISTRY_RECORD | EVENT | REGISTRY_ATTRIBUTED | V4_ADDED |
| `research.measurement` | measurement | INDUSTRY, SOFTWARE_PRODUCT | DERIVED_MEASUREMENT | PERIOD | INTERNAL_ONLY | V4_ADDED |
| `review.measurement` | measurement | APPLICATION, LOCATION, ORG, SOFTWARE_PRODUCT | DERIVED_MEASUREMENT, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `review.metrics` | legacy.reputation | ORG, LOCATION, BRAND | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V3_REVISED |
| `review.owner_response` | reviews | ORG, LOCATION | FIRST_PARTY_STATEMENT | EVENT | ATTRIBUTED_ONLY | V4_ADDED |
| `review.record` | reviews | ORG, LOCATION, SOFTWARE_PRODUCT, APPLICATION, LISTING | THIRD_PARTY_REPORT | EVENT | ATTRIBUTED_ONLY | V4_ADDED |
| `review.response_ratio` | legacy.reputation | ORG, LOCATION, BRAND | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V3_RETAINED |
| `review.statement` | reviews | ORG, LOCATION, SOFTWARE_PRODUCT, APPLICATION | THIRD_PARTY_REPORT | EVENT | ATTRIBUTED_ONLY | V4_ADDED |
| `review.theme_classification` | reviews | ORG, LOCATION, SOFTWARE_PRODUCT, APPLICATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `review.theme_summary` | research | ORG, LOCATION | DERIVED_MEASUREMENT | PERIOD | INTERNAL_ONLY | V4_ADDED |
| `schema.jsonld.present` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `schema.jsonld.types` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `schema.subject_binding` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `search.result` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `seo.ai_visibility.cited_in` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `seo.authority` | legacy.content_seo | ORG, LOCATION, BRAND | PROVIDER_ESTIMATE, FIRST_PARTY_STATEMENT | POINT | ESTIMATE_ATTRIBUTED | V3_RETAINED |
| `seo.cwv.field` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `seo.indexation` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `seo.keyword.footprint` | legacy.content_seo | ORG, LOCATION, BRAND | PROVIDER_ESTIMATE, FIRST_PARTY_STATEMENT | POINT | ESTIMATE_ATTRIBUTED | V3_RETAINED |
| `seo.local.presence` | legacy.content_seo | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `seo.measurement` | measurement | LOCATION, ORG, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, PROVIDER_ESTIMATE, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `shopping.listing` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `shopping.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `status.page.present` | legacy.infrastructure | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `suppression.dnc` | legacy.operational | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.ai_surface_readiness` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.automation_maturity` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.business_type` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.data_quality` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.growth_posture` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.icp_fit` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.industry` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.location_model` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.marketing_maturity` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.platform_camp` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.regulated_vertical` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.sales_maturity` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.seasonality` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.size_class` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tag.stack_complexity` | legacy.derived_tags | ORG, LOCATION, BRAND | INFERENCE | POINT | INTERNAL_ONLY | V3_RETAINED |
| `tech.rollback` | legacy.change | ORG, LOCATION, BRAND | DERIVED_MEASUREMENT | POINT | INTERNAL_ONLY | V3_RETAINED |
| `technology.account_identifier` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | INTERNAL_ONLY | V4_ADDED |
| `technology.change` | technology | ORG, LOCATION | DERIVED_MEASUREMENT | EVENT | INTERNAL_ONLY | V4_ADDED |
| `technology.cooccurrence` | technology | ORG, LOCATION | DERIVED_MEASUREMENT | POINT | INTERNAL_ONLY | V4_ADDED |
| `technology.cookie` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.csp` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.footprint` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.form_action` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.header` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.measurement` | measurement | APPLICATION, LISTING, LOCATION, ORG, SOFTWARE_PRODUCT, WEBSITE | DERIVED_MEASUREMENT, DIRECT_OBSERVATION, THIRD_PARTY_REPORT | PERIOD | ATTRIBUTED_ONLY | V4_ADDED |
| `technology.network_request` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.provider_report` | technology | ORG, LOCATION | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `technology.script` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.static_global` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `technology.subdomain` | technology | ORG, LOCATION | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V4_ADDED |
| `traffic.measurement` | measurement | LOCATION, ORG, WEBSITE | PROVIDER_ESTIMATE | PERIOD | ESTIMATE_ATTRIBUTED | V4_ADDED |
| `vendor.certification_badge` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_REVISED |
| `vendor.mentioned` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `vendor.present` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `web.mention` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | THIRD_PARTY_REPORT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `web.mention_sentiment` | commodity_data | ORG, LOCATION, WEBSITE, APPLICATION, LISTING | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |
| `website.approval_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.billing_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.business_model_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.compliance_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.customer_type_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.data_reentry_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.document_type_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.follow_up_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.geographic_market_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.handoff_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.intake_method_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.intent_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.knowledge_source_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.lead_channel_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.manual_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.platform` | legacy.technology | ORG, LOCATION, BRAND | DIRECT_OBSERVATION | POINT | DIRECT_SCOPED | V3_RETAINED |
| `website.reporting_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.role_responsibility_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.sales_motion_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.scheduling_process_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.service_offering_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `website.workflow_step_statement` | website_analysis | ORG, LOCATION | FIRST_PARTY_STATEMENT | POINT | ATTRIBUTED_ONLY | V4_ADDED |
| `workflow.hypothesis` | website_analysis | ORG, LOCATION | INFERENCE | POINT | INTERNAL_ONLY | V4_ADDED |

## Expansion procedure

Define a closed value and target schema, subject kinds, epistemic natures, permitted processors, reference rules, temporal behavior, absence behavior and copy policy. Add typed examples and boundary tests. Register a source only after its capture/retention/processing rights and implementation are approved. Enable commercial use independently of fact admission.
