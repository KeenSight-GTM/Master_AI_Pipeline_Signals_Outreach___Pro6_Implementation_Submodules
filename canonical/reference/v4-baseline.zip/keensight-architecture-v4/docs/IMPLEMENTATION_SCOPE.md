# Implemented versus specified

## Executable now

`generate.py` produces the schemas, registries, fixture records, content fixtures and release manifest. `--check` compares them without overwriting. `validate.py` reads actual files, verifies the release, dispatches object schemas and checks references, evidence, temporal rules and preview eligibility.

Pure reference helpers implement stable dependency ordering, scoped claim identity, conservative conflict resolution, strict JSON reading, evidence pointers, basic comparability, a narrow SCRIPT_HOST HTML fixture matcher, descriptive theme summaries and AND-requirement evaluation. Bundle.render implements three constrained preview sentence families.

`build_diagrams.py` emits full class diagrams from the exported schemas and a separate proposed-interface model. SVGs are rendered with Graphviz plus a small local sequence renderer; Mermaid sources are supplied but the Mermaid CLI was not run.

## Contract breadth, not 197 finished extractors

All 197 predicate definitions have typed value/target examples and registered semantics. All 89 metric definitions have typed dimension/value tests. All eleven user areas have declared mapping records. The synthetic example graph has 27 facts across those areas. This proves schema/link/check consistency for those fixtures, not real extraction accuracy or data-source completeness.

The 424 aggregate entries in the user's table are not supplied individually. No claim is made that all 424 line items were deduplicated, encoded or implemented. Approximately 2,500 SaaS signatures is a desired catalog scale, not an included signature count. The new bundle includes one narrow fixture fingerprint with six synthetic examples; no empirical precision estimate is claimed.

## Not implemented

No live source adapter, durable DB/content repository, generic fact ingestion service, production feature selector, real LLM call, paid API request, source license approval, public-registry resolution service, delivery integration, privacy deletion job, concurrency control or feedback optimizer was built. All such classes in the interface UML are proposed ports with method contracts.

The synthetic model/classifier executions are designated DESIGN_ONLY and are not enabled functions in the batch profile. They exist to validate their input/output/rights contracts. The actual enabled reference computations are the sample-summary and requirement-check functions.

## Previous assets

`reference/v3-contract-bundle.zip` is a byte-preserved original bundle. It retains the previous 18 signal definitions, 23 numerical reference derivations and 148-test baseline. The new test report concerns v4, not a rerun or replacement of the old baseline. Every original predicate identifier appears in v4, but the v4 envelope is intentionally not wire-compatible with v3.

The initial v4 profile contains three example signal definitions and three templates. Adapting previous business signals and numerical functions requires explicit input-selector, source and payload conformance. Nothing is automatically granted production authority merely because it worked in an older pipeline.

## Production release gates

A production implementation must prove repository immutability/idempotency and crash behavior; actual capture and extraction accuracy; attribution/collision resolution on real samples; source-specific permissions/retention; calibrated detector/model behavior; bounded cost and malicious-input handling; and current-use output checks. Delivery has additional gates and remains out of the initial scope.

The broad knowledge catalog should be maintained and expanded throughout those stages. The deployment stays small until workload or reliability measurements justify splitting modules.
