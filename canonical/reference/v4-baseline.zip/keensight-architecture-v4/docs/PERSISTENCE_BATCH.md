# Proposed persistence and batch runtime

## Initial deployment

One application; one transactional relational database; a local or object-backed content repository; one sequential batch runner. A process supervisor can run jobs, but a distributed queue is not a correctness prerequisite. Module names in the UML are not separate services.

## Logical persistence mapping

| Tables / collections | Primary content |
|---|---|
| subjects, external_identifiers | Namespaced identities and typed ORG/LOCATION/PERSON/PRODUCT/INDUSTRY/etc. subjects. |
| scopes, scope_resources, subject_bindings, binding_evidence | Capture boundaries, capture modality and attribution evidence. |
| artifacts, evidence_locators, evidence_sets, evidence_links, coverage_records/checks | Retained content metadata and exact raw/derived support. |
| facts, fact_changes | Append-only observation records plus explicit corrections/retractions. |
| claim_resolutions | Rebuildable evaluated results over exact observation IDs. |
| batch_runs, run_inputs, execution_records, execution_inputs/outputs | Pinned code/config/input references and wall-clock execution history. |
| research_samples, sample_members, context_assessments | Eligible sample membership, exclusions and explicit account-context joins. |
| signal_evaluations, outreach_packages, grounded_clauses | Immutable evaluation outputs and reviewed previews. |
| model_calls, repair_attempts | Raw I/O metadata and bounded parsing/repair history. |
| registry_releases, source_approvals | Immutable release manifests and current policy/authority decisions. |
| exposures, outcome_events | Reserved future identities; no delivery runtime is enabled. |

Embedded typed JSON is appropriate for predicate-dispatched values; it is not an unvalidated dictionary. Foreign keys, unique identities and transactional validation remain mandatory. This table is a proposed physical mapping, not delivered SQL migrations.

## Atomicity and retry rules

Persist and verify the blob before committing its reference. Use idempotency keys scoped to tenant, source operation and logical record identity. Same key/same canonical payload returns the existing record; same key/different payload fails. Do not overwrite another provider's observation.

Publish a complete account evaluation and its package revision together. Intermediate facts may exist independently for reuse, but partial outputs cannot appear as approved packages. A failed account is retried independently; use the same frozen input selection for the same retry identity, or create a new run when selecting different evidence.

No universal 14-event-kind journal, hash chain or total-order ledger is required for this profile. Record corrections with ChangeRecord and retain enough history to explain a result. Tamper-evident journal and full state-replay can be added later if a concrete audit requirement justifies them.

## Consistent evaluation without global epochs

Freeze a bounded set of exact input IDs and binding references for an account at logical `as_of`. Pin the complete registry/code release and profile. Run declared dependencies in a stable sequential order; parent outputs may be consumed after they are committed/recorded. Do not scan a moving latest-state view in the middle of an evaluation.

Wall-clock computation may occur after logical as_of. Exact source observations and their capture periods cannot come from the future relative to that cutoff. Current-use checks are separate from historical evaluation and must happen at approval/export time.

On a source change, retraction, expiry, binding correction or rights revocation, rerun/revalidate the account conservatively. There is no initial incremental dependency scheduler. No feedback from an incomplete evaluation may mutate that evaluation's rule set.

## Real adapter prerequisites

Before enabling a fetcher: scope/robots/rate policy as appropriate, request and body limits, destination restrictions against internal-network access, redirect rechecks, timeouts and safe parsing. Before enabling a paid model/API: serial bounded operation or atomic shared reservation when concurrency/overlapping runs is possible. Before model use: authorized inputs, task/schema bounds, no source-content instructions promoted into system policy, raw I/O retention, maximum two repair attempts and terminal abstention.

These behaviors are interface/acceptance requirements. No real fetcher, budget manager or model gateway is implemented in this bundle.

## Export and delivery

Current profile ends at DESIGN_TEST_APPROVED preview. A production export adapter must recheck OUTREACH and EXPORT rights, attribution, freshness, suppression and privacy. A future sender needs business-send identity, deduplication, provider outcome reconciliation and current restrictions. Unknown provider acceptance must not trigger blind retries; CRM synchronization failures must never resend a message.

Exposure/OutcomeEvent shapes preserve future identity and deduplication boundaries only. They do not implement mature reply-rate denominators, feedback optimization or sending.
