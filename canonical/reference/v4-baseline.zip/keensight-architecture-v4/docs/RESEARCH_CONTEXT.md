# Product and industry research context — combination C

Account evidence and product/industry evidence share the governed fact store but not subject identity. Shared storage never grants permission to transfer an assertion between subjects.

## Supported chain

1. Retain an approved product-review or forum artifact under source policy.
2. Extract an attributed statement or record with origin identity and source locator.
3. Record theme classifications as INFERENCE with exact parents and function/model version.
4. Construct ResearchSample: selected/eligible/excluded records, subject, time window, selection method, minimum sample policy and restrictions.
5. Compute a ResearchPriorValue with deduplicated supporting and eligible records, theme, sample share, scope and `population_claim=false`.
6. Join a separate eligible account fact through a registered ContextJoinRule to that exact product or industry.
7. Record ContextAssessment as internal context. Preserve the prior's actual subject and epistemic meaning.

The delivered product example is a three-record synthetic sample with two reporting-theme supports. It is not evidence about a real vendor's quality. The local and industry examples are also synthetic. Thresholds are design-test settings, not empirical calibration.

## What the join can and cannot do

A footprint link establishes an observed association on a captured surface. It does not prove a paid license, organization-wide deployment, current feature use or operational problem. Membership links identify a declared industry relationship under the approved predicate. Provider reports, mere mentions and inferred memberships must remain distinguishable and require their own permitted join rule.

The join may enrich an analyst's account context, prioritize a question or justify an additional authorized check. It may not emit a new direct account-pain fact, satisfy a template's account-specific evidence requirement, or turn a third-party complaint into first-party confirmation.

Cross-tenant joins, wrong-product joins, unsupported natures, extra hops, stale parents and company-claim flag changes are rejected by the reference checks.

## Sample interpretation

Counts represent deduplicated origin records, not necessarily independent authors or independent experiences. Syndicated copies must preserve/crosswalk origin identity; unresolved duplicates should be flagged/excluded according to the sample policy. A source-provided relevance sample is not a random sample. Individual record deletion invalidates affected summaries at current-use checks; production retention jobs must recompute or withdraw impacted results.

Minimum size and theme-support requirements belong to each consuming rule. Do not use a universal numeric threshold as a surrogate for representativeness. Statistics remain descriptive unless a separate sampling design and inference method have been specified and validated.

## LLM and copy boundary

Raw model requests, responses, model/task configuration and every repair attempt remain linked to the execution. A schema-valid theme is not automatically a correct theme. Exact-quote checks prove that extracted wording exists; they do not prove the classifier understood it. Calibration and sampled review remain release gates for real extraction functions.

Only approved account-evidence renderers produce outward clauses. A product/industry prior may be present in internal ContextAssessment but never in GroundedClause.fact_ids as account proof.

```mermaid
flowchart TB
  A["Account: observed product footprint"]
  B["Software product subject"]
  C["Approved product reviews / forum records"]
  D["Attributed statements and classifications"]
  E["Bounded sample with deduplication and denominator"]
  F["Product-level prior"]
  G["Explicit same-tenant context join"]
  H["Internal investigation or question selection"]
  I["Account-specific facts for outward claims"]
  X["No transfer of product pain into company fact"]
  A -->|"references product identity"| B
  C --> D
  D --> E
  E --> F
  B -->|"relationship evidence"| G
  F -->|"same product only"| G
  G -->|"non-company-claim context"| H
  H -->|"request additional evidence"| I
  G -->|"hard boundary"| X
```
