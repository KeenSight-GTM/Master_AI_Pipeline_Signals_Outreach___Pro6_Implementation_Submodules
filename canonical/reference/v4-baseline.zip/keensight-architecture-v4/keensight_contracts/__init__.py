"""KeenSight v4 design-time contracts and pure validation helpers.

No live collectors, database runtime, or sending integrations are implemented.
"""
__version__ = "4.0.0"
