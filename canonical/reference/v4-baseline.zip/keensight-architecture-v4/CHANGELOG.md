# v4 changes from the prior architecture

## Incorporated

Broader fact admission independent of first-release signals; all eleven areas; four configurable capability suites; first-class product/industry context; one batch application rather than a mandatory general scheduler.

## Preserved

All 87 prior predicate identifiers; strict validation; source authority; evidence and subject references; scoped absence; multivalued observation identity; provenance; current-use freshness checks; grounded outward claims; v3 original archive and numerical-reference assets.

## Added or corrected

110 predicate definitions; 89 explicit metric definitions; software-product/industry and other typed subjects; nature separate from capture method and processor; typed salary/review/discussion/registry/call payloads; explicit sample denominators; controlled internal context joins; real code-release pin; reporting timezone and periods; observed versus provider-reported tooling; named statement and record identity; exact LLM quote/input retention checks; conditional rather than universal maturity gating.

## Reduced initial infrastructure

No universal hash-chained journal, global evaluation epoch, durable incremental scheduler, graph database, automated feedback optimization or automatic delivery. Ordinary retained observations, transactions, input pinning, conservative account reevaluation and preview validation are the initial contracts.

## Boundaries

No production runtime, live provider adapter, licensed dataset, actual model call or 2,500-signature library was added. The current three example signals/templates do not claim to reimplement every v3 business rule. Contract/reference code and documentation were changed locally; neither linked GitHub repository was modified.
